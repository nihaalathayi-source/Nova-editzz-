package com.example.ui.screens

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.data.AppDatabase
import com.example.data.ProjectEntity
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SurfaceVariantDark
import com.example.utils.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

enum class PhotoEditorTab {
    CROP_ROTATE, ADJUST, FILTER, TEXT, STICKERS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoEditorScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var activeTab by remember { mutableStateOf(PhotoEditorTab.CROP_ROTATE) }

    // Adjustments
    var brightness by remember { mutableFloatStateOf(0f) } // -50 to 50
    var contrast by remember { mutableFloatStateOf(1f) } // 0.5 to 2.0
    var saturation by remember { mutableFloatStateOf(1f) } // 0 to 2.0

    // Transform
    var rotationDegrees by remember { mutableFloatStateOf(0f) }
    var scaleFactor by remember { mutableFloatStateOf(1.0f) }
    var isFlippedHorizontally by remember { mutableStateOf(false) }

    // Filter
    var selectedFilter by remember { mutableStateOf(EditorFilter.NONE) }

    // Text & Stickers
    var overlayText by remember { mutableStateOf("") }
    var textColor by remember { mutableStateOf(Color.White) }
    var textScale by remember { mutableFloatStateOf(1.0f) }
    var showTextDialog by remember { mutableStateOf(false) }
    var stickerEmoji by remember { mutableStateOf<String?>(null) }
    var stickerX by remember { mutableFloatStateOf(0.5f) }
    var stickerY by remember { mutableFloatStateOf(0.5f) }

    // Save state
    var isSaving by remember { mutableStateOf(false) }
    var savedFile by remember { mutableStateOf<File?>(null) }

    BackHandler {
        onNavigateBack()
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            imageUri = uri
            // reset adjustments for new photo
            brightness = 0f
            contrast = 1f
            saturation = 1f
            rotationDegrees = 0f
            scaleFactor = 1.0f
            selectedFilter = EditorFilter.NONE
        }
    }

    LaunchedEffect(Unit) {
        if (imageUri == null) {
            // Auto open picker or use sample photo
            val sampleUris = withContext(Dispatchers.IO) { createSamplePhotoUris(context) }
            imageUri = sampleUris.firstOrNull()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Photo Editor", fontSize = 18.sp, color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Photo", tint = PrimaryBlue)
                    }

                    Button(
                        onClick = {
                            if (imageUri == null) return@Button
                            isSaving = true
                            coroutineScope.launch {
                                val result = saveEditedPhoto(
                                    context = context,
                                    sourceUri = imageUri!!,
                                    rotation = rotationDegrees,
                                    scale = scaleFactor,
                                    brightness = brightness,
                                    contrast = contrast,
                                    saturation = saturation,
                                    filter = selectedFilter,
                                    text = overlayText,
                                    sticker = stickerEmoji,
                                    stickerX = stickerX,
                                    stickerY = stickerY
                                )
                                isSaving = false
                                savedFile = result
                                if (result != null) {
                                    Toast.makeText(context, "✅ Photo saved to Gallery!", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Preview Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF0F0F16)),
                contentAlignment = Alignment.Center
            ) {
                if (imageUri != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize(0.92f)
                            .clip(RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Color filter Matrix for Adjustments
                        val composeColorMatrix = remember(brightness, contrast, saturation, selectedFilter) {
                            buildComposeColorMatrix(brightness, contrast, saturation, selectedFilter)
                        }

                        AsyncImage(
                            model = imageUri,
                            contentDescription = "Editing Image",
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    rotationZ = rotationDegrees
                                    scaleX = scaleFactor * (if (isFlippedHorizontally) -1f else 1f)
                                    scaleY = scaleFactor
                                },
                            contentScale = ContentScale.Fit,
                            colorFilter = ColorFilter.colorMatrix(composeColorMatrix)
                        )

                        // Text Overlay
                        if (overlayText.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 24.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    overlayText,
                                    color = textColor,
                                    fontSize = (22 * textScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Sticker Overlay
                        if (stickerEmoji != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .pointerInput(stickerEmoji) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            stickerX = (stickerX + dragAmount.x / size.width).coerceIn(0.1f, 0.9f)
                                            stickerY = (stickerY + dragAmount.y / size.height).coerceIn(0.1f, 0.9f)
                                        }
                                    }
                            ) {
                                Text(
                                    text = stickerEmoji!!,
                                    fontSize = 48.sp,
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .graphicsLayer {
                                            translationX = stickerX * 300f
                                            translationY = stickerY * 300f
                                        }
                                )
                            }
                        }
                    }
                } else {
                    Text("Select a photo to start editing", color = Color.Gray)
                }
            }

            // Controls Tabs Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceVariantDark)
            ) {
                ScrollableTabRow(
                    selectedTabIndex = activeTab.ordinal,
                    containerColor = SurfaceVariantDark,
                    contentColor = PrimaryBlue,
                    edgePadding = 12.dp,
                    divider = {}
                ) {
                    Tab(
                        selected = activeTab == PhotoEditorTab.CROP_ROTATE,
                        onClick = { activeTab = PhotoEditorTab.CROP_ROTATE },
                        text = { Text("Transform", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Crop, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = activeTab == PhotoEditorTab.ADJUST,
                        onClick = { activeTab = PhotoEditorTab.ADJUST },
                        text = { Text("Adjust", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = activeTab == PhotoEditorTab.FILTER,
                        onClick = { activeTab = PhotoEditorTab.FILTER },
                        text = { Text("Filter", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.FilterBAndW, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = activeTab == PhotoEditorTab.TEXT,
                        onClick = { activeTab = PhotoEditorTab.TEXT },
                        text = { Text("Text", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Title, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = activeTab == PhotoEditorTab.STICKERS,
                        onClick = { activeTab = PhotoEditorTab.STICKERS },
                        text = { Text("Stickers", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.EmojiEmotions, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }

                // Controls Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    when (activeTab) {
                        PhotoEditorTab.CROP_ROTATE -> {
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Zoom / Scale: ${(scaleFactor * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        IconButton(onClick = { rotationDegrees = (rotationDegrees + 90f) % 360f }) {
                                            Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = PrimaryBlue)
                                        }
                                        IconButton(onClick = { isFlippedHorizontally = !isFlippedHorizontally }) {
                                            Icon(Icons.Default.Flip, contentDescription = "Flip", tint = PrimaryBlue)
                                        }
                                        IconButton(onClick = {
                                            scaleFactor = 1.0f
                                            rotationDegrees = 0f
                                            isFlippedHorizontally = false
                                        }) {
                                            Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = Color.Gray)
                                        }
                                    }
                                }
                                Slider(
                                    value = scaleFactor,
                                    onValueChange = { scaleFactor = it },
                                    valueRange = 0.5f..2.5f
                                )
                            }
                        }

                        PhotoEditorTab.ADJUST -> {
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Brightness", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(75.dp))
                                    Slider(
                                        value = brightness,
                                        onValueChange = { brightness = it },
                                        valueRange = -50f..50f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${brightness.toInt()}", color = PrimaryBlue, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Contrast", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(75.dp))
                                    Slider(
                                        value = contrast,
                                        onValueChange = { contrast = it },
                                        valueRange = 0.5f..2.0f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(String.format("%.1fx", contrast), color = PrimaryBlue, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Saturation", color = Color.White, fontSize = 11.sp, modifier = Modifier.width(75.dp))
                                    Slider(
                                        value = saturation,
                                        onValueChange = { saturation = it },
                                        valueRange = 0f..2.0f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(String.format("%.1fx", saturation), color = PrimaryBlue, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                                }
                            }
                        }

                        PhotoEditorTab.FILTER -> {
                            val filters = listOf(
                                EditorFilter.NONE,
                                EditorFilter.GRAYSCALE,
                                EditorFilter.SEPIA,
                                EditorFilter.WARM,
                                EditorFilter.COOL,
                                EditorFilter.INVERT
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                filters.forEach { filter ->
                                    val isSelected = selectedFilter == filter
                                    Card(
                                        onClick = { selectedFilter = filter },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) PrimaryPurple.copy(alpha = 0.35f) else Color(0xFF1E1E2C)
                                        ),
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPurple) else null,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.size(76.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize().padding(6.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                Icons.Default.FilterBAndW,
                                                contentDescription = null,
                                                tint = if (isSelected) PrimaryPurple else Color.LightGray,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                filter.title,
                                                fontSize = 10.sp,
                                                color = if (isSelected) Color.White else Color.LightGray,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        PhotoEditorTab.TEXT -> {
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { showTextDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                                    ) {
                                        Icon(Icons.Default.Title, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (overlayText.isEmpty()) "Add Caption" else "Edit Caption")
                                    }

                                    if (overlayText.isNotEmpty()) {
                                        TextButton(onClick = { overlayText = "" }) {
                                            Text("Remove Text", color = Color(0xFFFF5252))
                                        }
                                    }
                                }

                                if (overlayText.isNotEmpty()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Size: ${(textScale * 100).toInt()}%", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(80.dp))
                                        Slider(
                                            value = textScale,
                                            onValueChange = { textScale = it },
                                            valueRange = 0.5f..2.5f,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }

                        PhotoEditorTab.STICKERS -> {
                            val stickersList = listOf("✨", "❤️", "🔥", "📸", "⭐", "🎉", "🌴", "🌸", "👑", "⚡", "🦋", "😎")
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                                Text("Tap to add sticker to photo:", color = Color.Gray, fontSize = 11.sp)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    stickersList.forEach { emoji ->
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF1E1E2C))
                                                .clickable {
                                                    stickerEmoji = emoji
                                                    stickerX = 0.5f
                                                    stickerY = 0.5f
                                                    Toast.makeText(context, "Added $emoji (Drag to position)", Toast.LENGTH_SHORT).show()
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(emoji, fontSize = 22.sp)
                                        }
                                    }
                                }
                                if (stickerEmoji != null) {
                                    TextButton(onClick = { stickerEmoji = null }) {
                                        Text("Remove Sticker", color = Color(0xFFFF5252), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTextDialog) {
        var tempText by remember { mutableStateOf(overlayText) }
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Add Text Caption", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = tempText,
                    onValueChange = { tempText = it },
                    placeholder = { Text("Type caption here...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        overlayText = tempText
                        showTextDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTextDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF1E1E2C)
        )
    }

    if (savedFile != null) {
        AlertDialog(
            onDismissRequest = { savedFile = null },
            title = { Text("Photo Saved!", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Your photo has been exported in HD and saved directly to your phone's Gallery (Pictures/NovaEdit)!",
                    color = Color.LightGray
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = savedFile ?: return@Button
                        try {
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "image/jpeg"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Photo"))
                        } catch (e: Exception) {
                            Toast.makeText(context, "Share: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                        savedFile = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Share")
                }
            },
            dismissButton = {
                TextButton(onClick = { savedFile = null }) {
                    Text("Done", color = Color.White)
                }
            },
            containerColor = Color(0xFF1E1E2C)
        )
    }
}

fun buildComposeColorMatrix(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    filter: EditorFilter
): ComposeColorMatrix {
    val matrix = ComposeColorMatrix()

    // 1. Saturation
    matrix.setToSaturation(saturation)

    // 2. Adjust filter
    when (filter) {
        EditorFilter.GRAYSCALE -> matrix.setToSaturation(0f)
        EditorFilter.SEPIA -> {
            val sepiaMatrix = ComposeColorMatrix(
                floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.timesAssign(sepiaMatrix)
        }
        EditorFilter.WARM -> {
            val warmMatrix = ComposeColorMatrix(
                floatArrayOf(
                    1.2f, 0f, 0f, 0f, 0f,
                    0f, 1.05f, 0f, 0f, 0f,
                    0f, 0f, 0.85f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.timesAssign(warmMatrix)
        }
        EditorFilter.COOL -> {
            val coolMatrix = ComposeColorMatrix(
                floatArrayOf(
                    0.85f, 0f, 0f, 0f, 0f,
                    0f, 1.0f, 0f, 0f, 0f,
                    0f, 0f, 1.25f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.timesAssign(coolMatrix)
        }
        EditorFilter.INVERT -> {
            val invertMatrix = ComposeColorMatrix(
                floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            matrix.timesAssign(invertMatrix)
        }
        else -> {}
    }

    return matrix
}

suspend fun saveEditedPhoto(
    context: Context,
    sourceUri: Uri,
    rotation: Float,
    scale: Float,
    brightness: Float,
    contrast: Float,
    saturation: Float,
    filter: EditorFilter,
    text: String,
    sticker: String?,
    stickerX: Float,
    stickerY: Float
): File? = withContext(Dispatchers.IO) {
    try {
        val stream = context.contentResolver.openInputStream(sourceUri)
        val srcBitmap = BitmapFactory.decodeStream(stream)
        stream?.close() ?: return@withContext null

        val w = srcBitmap.width
        val h = srcBitmap.height
        val outputBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outputBitmap)

        val matrix = Matrix()
        matrix.postRotate(rotation, w / 2f, h / 2f)
        matrix.postScale(scale, scale, w / 2f, h / 2f)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val cm = ColorMatrix()
        cm.setSaturation(saturation)
        paint.colorFilter = ColorMatrixColorFilter(cm)

        canvas.drawBitmap(srcBitmap, matrix, paint)

        // Draw Text
        if (text.isNotBlank()) {
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = android.graphics.Color.WHITE
                textSize = w * 0.05f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                setShadowLayer(8f, 2f, 2f, android.graphics.Color.BLACK)
            }
            canvas.drawText(text, w / 2f, h * 0.9f, textPaint)
        }

        // Draw Sticker
        if (sticker != null) {
            val stickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = w * 0.12f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(sticker, w * stickerX, h * stickerY, stickerPaint)
        }

        val result = CollageExporter.saveCollageImageToGallery(context, outputBitmap, "NovaEdit_Photo")
        result.first
    } catch (_: Exception) {
        null
    }
}
