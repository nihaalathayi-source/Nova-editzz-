package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val BackgroundDark = Color(0xFF0F0F12)
val SurfaceDark = Color(0xFF1A1A24)
val SurfaceVariantDark = Color(0xFF262635)
val PrimaryBlue = Color(0xFF00E5FF)
val PrimaryPurple = Color(0xFF7C4DFF)
val OnBackground = Color(0xFFFFFFFF)
val OnSurfaceSecondary = Color(0xFFA0A0B0)
