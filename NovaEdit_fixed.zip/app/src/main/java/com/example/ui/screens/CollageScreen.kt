package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SurfaceVariantDark
import com.example.utils.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class CollageTab {
    LAYOUTS, SCALE_TRANSFORM, SPACING, RATIO, BACKGROUND, FILTERS, STICKERS_TEXT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollageScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Collage State
    var photos by remember { mutableStateOf<List<CollagePhoto>>(emptyList()) }
    var selectedPhotoIndex by remember { mutableIntStateOf(0) }
    var selectedLayout by remember { mutableStateOf(CollageLayoutType.GRID_2X2) }
    var currentTab by remember { mutableStateOf(CollageTab.LAYOUTS) }

    // Style State
    var spacingDp by remember { mutableFloatStateOf(8f) }
    var cornerRadiusDp by remember { mutableFloatStateOf(12f) }
    var borderWidthDp by remember { mutableFloatStateOf(0f) }
    var borderColor by remember { mutableStateOf(Color(0xFF7C4DFF)) }
    var aspectRatioWidth by remember { mutableIntStateOf(1) }
    var aspectRatioHeight by remember { mutableIntStateOf(1) }
    var selectedBgTheme by remember { mutableIntStateOf(0) }
    var overlayText by remember { mutableStateOf("") }
    var textColor by remember { mutableStateOf(Color.White) }
    var textScale by remember { mutableFloatStateOf(1.0f) }
    var stickers by remember { mutableStateOf<List<CollageSticker>>(emptyList()) }
    var selectedStickerId by remember { mutableStateOf<String?>(null) }

    // Export & Dialog States
    var showExportDialog by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(0) }
    var exportResultFile by remember { mutableStateOf<File?>(null) }
    var exportResultUri by remember { mutableStateOf<Uri?>(null) }
    var isExportVideo by remember { mutableStateOf(false) }
    var showAddTextDialog by remember { mutableStateOf(false) }

    // Handle back button
    BackHandler {
        onNavigateBack()
    }

    // Media Pickers
    val multiPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 9)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val newPhotos = uris.map { uri -> CollagePhoto(uri = uri) }
            photos = (photos + newPhotos).take(9)
            selectedPhotoIndex = 0
            selectedLayout = getRecommendedLayout(photos.size)
        }
    }

    val singlePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            if (photos.isNotEmpty() && selectedPhotoIndex in photos.indices) {
                // Replace selected photo
                photos = photos.toMutableList().also { list ->
                    list[selectedPhotoIndex] = list[selectedPhotoIndex].copy(uri = uri)
                }
            } else {
                photos = photos + CollagePhoto(uri = uri)
                selectedPhotoIndex = photos.size - 1
            }
        }
    }

    // Auto-launch picker or generate sample photos if empty initially
    fun loadSamplePhotos() {
        coroutineScope.launch {
            val sampleUris = withContext(Dispatchers.IO) {
                createSamplePhotoUris(context)
            }
            photos = sampleUris.map { CollagePhoto(uri = it) }
            selectedPhotoIndex = 0
            selectedLayout = CollageLayoutType.GRID_2X2
            Toast.makeText(context, "Loaded 4 sample photos for collage", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        if (photos.isEmpty()) {
            // Provide sample photos immediately so user can see and edit the collage instantly
            loadSamplePhotos()
        }
    }

    val backgroundThemes = listOf(
        Pair("Dark Slate", Pair(0xFF181824.toInt(), 0xFF0C0C14.toInt())),
        Pair("Clean White", Pair(0xFFFFFFFF.toInt(), 0xFFE0E0E0.toInt())),
        Pair("Sunset Coral", Pair(0xFFFF5722.toInt(), 0xFFFF9800.toInt())),
        Pair("Electric Violet", Pair(0xFF7C4DFF.toInt(), 0xFF3D5AFE.toInt())),
        Pair("Neon Cyan", Pair(0xFF00E5FF.toInt(), 0xFF1DE9B6.toInt())),
        Pair("Rose Gold", Pair(0xFFFF4081.toInt(), 0xFFFF80AB.toInt())),
        Pair("Deep Midnight", Pair(0xFF0F2027.toInt(), 0xFF2C5364.toInt())),
        Pair("Forest Olive", Pair(0xFF2E7D32.toInt(), 0xFF1B5E20.toInt()))
    )

    val currentBg = backgroundThemes[selectedBgTheme.coerceIn(backgroundThemes.indices)]

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Collage Maker",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = PrimaryPurple.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    "${photos.size} Photos",
                                    color = PrimaryPurple,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    // Add more photos button ("ஆட் பண்றது")
                    IconButton(
                        onClick = {
                            multiPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Add Photos", tint = PrimaryBlue)
                    }

                    // Save / Export button
                    Button(
                        onClick = { showExportDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // 1. COLLAGE CANVAS PREVIEW AREA
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF0F0F16))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                if (photos.isEmpty()) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Collections, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No photos in collage yet", color = Color.LightGray, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Add photos from gallery or load samples to start", color = Color.Gray, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = {
                                    multiPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Choose Photos")
                            }
                            OutlinedButton(onClick = { loadSamplePhotos() }) {
                                Text("Use Sample Photos", color = Color.White)
                            }
                        }
                    }
                } else {
                    // Render Collage Container with selected Aspect Ratio
                    Box(
                        modifier = Modifier
                            .aspectRatio(aspectRatioWidth.toFloat() / aspectRatioHeight.toFloat())
                            .fillMaxSize()
                            .shadow(16.dp, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(currentBg.second.first), Color(currentBg.second.second))
                                )
                            )
                            .then(
                                if (borderWidthDp > 0) {
                                    Modifier.border(borderWidthDp.dp, borderColor, RoundedCornerShape(12.dp))
                                } else Modifier
                            )
                    ) {
                        // Render Photos based on selected layout
                        CollageLayoutContent(
                            photos = photos,
                            layoutType = selectedLayout,
                            selectedIndex = selectedPhotoIndex,
                            spacingDp = spacingDp,
                            cornerRadiusDp = cornerRadiusDp,
                            onSelectPhoto = { index ->
                                selectedPhotoIndex = index
                                currentTab = CollageTab.SCALE_TRANSFORM
                            },
                            onPanPhoto = { index, dx, dy ->
                                photos = photos.toMutableList().also { list ->
                                    val p = list[index]
                                    list[index] = p.copy(
                                        offsetX = p.offsetX + dx,
                                        offsetY = p.offsetY + dy
                                    )
                                }
                            }
                        )

                        // Render Text Overlay
                        if (overlayText.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 20.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = overlayText,
                                    color = textColor,
                                    fontSize = (20 * textScale).sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Render Stickers / Badges
                        stickers.forEach { sticker ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .pointerInput(sticker.id) {
                                        detectDragGestures { change, dragAmount ->
                                            change.consume()
                                            stickers = stickers.map { s ->
                                                if (s.id == sticker.id) {
                                                    s.copy(
                                                        xPercent = (s.xPercent + dragAmount.x / size.width).coerceIn(0.1f, 0.9f),
                                                        yPercent = (s.yPercent + dragAmount.y / size.height).coerceIn(0.1f, 0.9f)
                                                    )
                                                } else s
                                            }
                                        }
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .graphicsLayer {
                                            translationX = sticker.xPercent * 300f
                                            translationY = sticker.yPercent * 300f
                                            scaleX = sticker.scale
                                            scaleY = sticker.scale
                                        }
                                        .clickable { selectedStickerId = sticker.id }
                                ) {
                                    Text(sticker.textOrEmoji, fontSize = 36.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Quick Photo Action Strip (when a photo is selected)
            if (photos.isNotEmpty() && selectedPhotoIndex in photos.indices) {
                Surface(
                    color = Color(0xFF1E1E2C),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Photo ${selectedPhotoIndex + 1}/${photos.size} Selected",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Rotate Photo
                            IconButton(
                                onClick = {
                                    photos = photos.toMutableList().also { list ->
                                        val p = list[selectedPhotoIndex]
                                        list[selectedPhotoIndex] = p.copy(rotation = (p.rotation + 90f) % 360f)
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.RotateRight, contentDescription = "Rotate", tint = Color.White, modifier = Modifier.size(18.dp))
                            }

                            // Flip Photo
                            IconButton(
                                onClick = {
                                    photos = photos.toMutableList().also { list ->
                                        val p = list[selectedPhotoIndex]
                                        list[selectedPhotoIndex] = p.copy(isFlipped = !p.isFlipped)
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Flip, contentDescription = "Flip", tint = Color.White, modifier = Modifier.size(18.dp))
                            }

                            // Replace Photo from Gallery
                            IconButton(
                                onClick = {
                                    singlePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Cached, contentDescription = "Replace", tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                            }

                            // Delete Photo ("டெலீட் பண்றது")
                            IconButton(
                                onClick = {
                                    if (photos.size > 1) {
                                        photos = photos.toMutableList().also { it.removeAt(selectedPhotoIndex) }
                                        selectedPhotoIndex = selectedPhotoIndex.coerceAtMost(photos.size - 1)
                                        selectedLayout = getRecommendedLayout(photos.size)
                                    } else {
                                        photos = emptyList()
                                    }
                                    Toast.makeText(context, "Photo removed from collage", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            // 2. COLLAGE EDITOR CONTROLS TABS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceVariantDark)
            ) {
                // Tab Selection Bar
                ScrollableTabRow(
                    selectedTabIndex = currentTab.ordinal,
                    containerColor = SurfaceVariantDark,
                    contentColor = PrimaryBlue,
                    edgePadding = 12.dp,
                    divider = {}
                ) {
                    Tab(
                        selected = currentTab == CollageTab.LAYOUTS,
                        onClick = { currentTab = CollageTab.LAYOUTS },
                        text = { Text("Layouts", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = currentTab == CollageTab.SCALE_TRANSFORM,
                        onClick = { currentTab = CollageTab.SCALE_TRANSFORM },
                        text = { Text("Scale/Zoom", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.ZoomIn, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = currentTab == CollageTab.SPACING,
                        onClick = { currentTab = CollageTab.SPACING },
                        text = { Text("Border/Gap", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.GridOn, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = currentTab == CollageTab.RATIO,
                        onClick = { currentTab = CollageTab.RATIO },
                        text = { Text("Ratio", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.AspectRatio, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = currentTab == CollageTab.BACKGROUND,
                        onClick = { currentTab = CollageTab.BACKGROUND },
                        text = { Text("Background", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.ColorLens, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = currentTab == CollageTab.FILTERS,
                        onClick = { currentTab = CollageTab.FILTERS },
                        text = { Text("Filters", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.FilterBAndW, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                    Tab(
                        selected = currentTab == CollageTab.STICKERS_TEXT,
                        onClick = { currentTab = CollageTab.STICKERS_TEXT },
                        text = { Text("Text/Stickers", fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Title, contentDescription = null, modifier = Modifier.size(18.dp)) }
                    )
                }

                // Tab Content Panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    when (currentTab) {
                        CollageTab.LAYOUTS -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CollageLayoutType.values().forEach { layout ->
                                    val isSelected = selectedLayout == layout
                                    Card(
                                        onClick = { selectedLayout = layout },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) PrimaryPurple.copy(alpha = 0.25f) else Color(0xFF1E1E2C)
                                        ),
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPurple) else null,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .width(76.dp)
                                            .height(88.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize().padding(6.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            // Mini schematic layout icon
                                            MiniLayoutPreview(layout = layout, isSelected = isSelected)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                layout.title,
                                                fontSize = 10.sp,
                                                color = if (isSelected) Color.White else Color.LightGray,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        CollageTab.SCALE_TRANSFORM -> {
                            // "கிராபிக்ஸ் ஸ்கேல்" (Graphics Scale & Zoom slider)
                            if (photos.isNotEmpty() && selectedPhotoIndex in photos.indices) {
                                val currentPhoto = photos[selectedPhotoIndex]
                                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "Graphics Scale / Zoom (Photo ${selectedPhotoIndex + 1})",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            String.format("%.1fx", currentPhoto.scale),
                                            color = PrimaryBlue,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Slider(
                                        value = currentPhoto.scale,
                                        onValueChange = { newScale ->
                                            photos = photos.toMutableList().also { list ->
                                                list[selectedPhotoIndex] = currentPhoto.copy(scale = newScale)
                                            }
                                        },
                                        valueRange = 0.5f..3.0f,
                                        colors = SliderDefaults.colors(
                                            thumbColor = PrimaryBlue,
                                            activeTrackColor = PrimaryBlue
                                        )
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                photos = photos.toMutableList().also { list ->
                                                    list[selectedPhotoIndex] = currentPhoto.copy(
                                                        scale = 1.0f,
                                                        offsetX = 0f,
                                                        offsetY = 0f,
                                                        rotation = 0f,
                                                        isFlipped = false
                                                    )
                                                }
                                            },
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                        ) {
                                            Text("Reset Scale", fontSize = 11.sp, color = Color.White)
                                        }

                                        Button(
                                            onClick = {
                                                singlePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Add/Replace", fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = {
                                                if (photos.size > 1) {
                                                    photos = photos.toMutableList().also { it.removeAt(selectedPhotoIndex) }
                                                    selectedPhotoIndex = selectedPhotoIndex.coerceAtMost(photos.size - 1)
                                                    selectedLayout = getRecommendedLayout(photos.size)
                                                } else {
                                                    photos = emptyList()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Delete", fontSize = 11.sp)
                                        }
                                    }
                                }
                            } else {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("Tap any photo in the collage to scale or adjust", color = Color.Gray)
                                }
                            }
                        }

                        CollageTab.SPACING -> {
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Inner Gap:", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(90.dp))
                                    Slider(
                                        value = spacingDp,
                                        onValueChange = { spacingDp = it },
                                        valueRange = 0f..24f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${spacingDp.toInt()}dp", color = PrimaryBlue, fontSize = 12.sp, modifier = Modifier.width(40.dp))
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Round Corners:", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(90.dp))
                                    Slider(
                                        value = cornerRadiusDp,
                                        onValueChange = { cornerRadiusDp = it },
                                        valueRange = 0f..32f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${cornerRadiusDp.toInt()}dp", color = PrimaryBlue, fontSize = 12.sp, modifier = Modifier.width(40.dp))
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Outer Border:", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(90.dp))
                                    Slider(
                                        value = borderWidthDp,
                                        onValueChange = { borderWidthDp = it },
                                        valueRange = 0f..12f,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${borderWidthDp.toInt()}dp", color = PrimaryBlue, fontSize = 12.sp, modifier = Modifier.width(40.dp))
                                }
                            }
                        }

                        CollageTab.RATIO -> {
                            val ratios = listOf(
                                Triple("1:1", 1, 1),
                                Triple("4:5", 4, 5),
                                Triple("9:16", 9, 16),
                                Triple("16:9", 16, 9),
                                Triple("3:4", 3, 4)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ratios.forEach { (label, w, h) ->
                                    val isSelected = aspectRatioWidth == w && aspectRatioHeight == h
                                    Card(
                                        onClick = {
                                            aspectRatioWidth = w
                                            aspectRatioHeight = h
                                        },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) PrimaryBlue.copy(alpha = 0.25f) else Color(0xFF1E1E2C)
                                        ),
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PrimaryBlue) else null,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.size(76.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize(),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(label, fontWeight = FontWeight.Bold, color = if (isSelected) PrimaryBlue else Color.White, fontSize = 16.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                when (label) {
                                                    "1:1" -> "Square"
                                                    "4:5" -> "Feed"
                                                    "9:16" -> "Story/Reels"
                                                    "16:9" -> "YouTube"
                                                    else -> "Standard"
                                                },
                                                fontSize = 9.sp,
                                                color = Color.Gray
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        CollageTab.BACKGROUND -> {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                backgroundThemes.forEachIndexed { index, (name, colors) ->
                                    val isSelected = selectedBgTheme == index
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.clickable { selectedBgTheme = index }
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(54.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(Color(colors.first), Color(colors.second))
                                                    )
                                                )
                                                .border(
                                                    width = if (isSelected) 3.dp else 1.dp,
                                                    color = if (isSelected) Color.White else Color.Transparent,
                                                    shape = CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(name, color = if (isSelected) Color.White else Color.Gray, fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        CollageTab.FILTERS -> {
                            val filters = listOf(
                                EditorFilter.NONE,
                                EditorFilter.GRAYSCALE,
                                EditorFilter.SEPIA,
                                EditorFilter.WARM,
                                EditorFilter.COOL,
                                EditorFilter.INVERT
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                filters.forEach { filter ->
                                    val currentFilter = if (photos.isNotEmpty() && selectedPhotoIndex in photos.indices) {
                                        photos[selectedPhotoIndex].filter
                                    } else EditorFilter.NONE
                                    val isSelected = currentFilter == filter

                                    Card(
                                        onClick = {
                                            if (photos.isNotEmpty() && selectedPhotoIndex in photos.indices) {
                                                photos = photos.toMutableList().also { list ->
                                                    list[selectedPhotoIndex] = list[selectedPhotoIndex].copy(filter = filter)
                                                }
                                            }
                                        },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) PrimaryPurple.copy(alpha = 0.3f) else Color(0xFF1E1E2C)
                                        ),
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPurple) else null,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.width(78.dp).height(80.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize().padding(6.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                Icons.Default.FilterBAndW,
                                                contentDescription = null,
                                                tint = if (isSelected) PrimaryPurple else Color.LightGray,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                filter.title,
                                                fontSize = 10.sp,
                                                color = if (isSelected) Color.White else Color.LightGray,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        CollageTab.STICKERS_TEXT -> {
                            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { showAddTextDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Title, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (overlayText.isEmpty()) "Add Title" else "Edit Title", fontSize = 12.sp)
                                    }

                                    if (overlayText.isNotEmpty()) {
                                        IconButton(onClick = { overlayText = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear text", tint = Color.Gray)
                                        }
                                    }
                                }

                                Text("Add Emojis / Stickers:", color = Color.Gray, fontSize = 11.sp)

                                val emojis = listOf("✨", "❤️", "🔥", "📸", "⭐", "🎉", "🌴", "🌸", "👑", "⚡")
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    emojis.forEach { emoji ->
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF1E1E2C))
                                                .clickable {
                                                    stickers = stickers + CollageSticker(
                                                        textOrEmoji = emoji,
                                                        xPercent = 0.5f,
                                                        yPercent = 0.5f,
                                                        scale = 1.0f
                                                    )
                                                    Toast.makeText(context, "Added $emoji (Drag to position)", Toast.LENGTH_SHORT).show()
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(emoji, fontSize = 20.sp)
                                        }
                                    }
                                    if (stickers.isNotEmpty()) {
                                        TextButton(onClick = { stickers = emptyList() }) {
                                            Text("Clear Stickers", color = Color(0xFFFF5252), fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Text Overlay Dialog
    if (showAddTextDialog) {
        var tempText by remember { mutableStateOf(overlayText) }
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text("Collage Title / Overlay Text", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = tempText,
                        onValueChange = { tempText = it },
                        placeholder = { Text("e.g. Summer Memories, Weekend Vibes") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Scale: ${(textScale * 100).toInt()}%", color = Color.Gray, fontSize = 12.sp)
                    Slider(
                        value = textScale,
                        onValueChange = { textScale = it },
                        valueRange = 0.6f..2.5f
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        overlayText = tempText
                        showAddTextDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF1E1E2C)
        )
    }

    // Export Options & Download Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = {
                if (!isExporting) showExportDialog = false
            },
            title = {
                Text("Export & Download Collage", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (isExporting) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                progress = { exportProgress / 100f },
                                color = PrimaryBlue,
                                modifier = Modifier.size(60.dp),
                                strokeWidth = 5.dp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                if (isExportVideo) "Encoding HD MP4 Video ($exportProgress%)..." else "Generating HD Image ($exportProgress%)...",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Saving straight to Device Gallery without errors...", color = Color.Gray, fontSize = 12.sp)
                        }
                    } else if (exportResultFile != null) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(52.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Saved Successfully!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                if (isExportVideo) "✅ MP4 Video saved to Gallery (Movies/NovaEdit)" else "✅ HD Image saved to Gallery (Pictures/NovaEdit)",
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                Button(
                                    onClick = {
                                        val file = exportResultFile ?: return@Button
                                        try {
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                            val mime = if (isExportVideo) "video/mp4" else "image/jpeg"
                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(uri, mime)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Cannot open: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                                ) {
                                    Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open File")
                                }

                                Button(
                                    onClick = {
                                        val file = exportResultFile ?: return@Button
                                        try {
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                            val mime = if (isExportVideo) "video/mp4" else "image/jpeg"
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = mime
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Collage"))
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Share: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Share")
                                }
                            }
                        }
                    } else {
                        Text(
                            "Choose your export format to download directly into your phone's Gallery:",
                            color = Color.LightGray,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        // Option 1: Download HD Image
                        Card(
                            onClick = {
                                isExportVideo = false
                                isExporting = true
                                exportProgress = 20
                                coroutineScope.launch {
                                    try {
                                        val style = CollageStyle(
                                            spacingDp = spacingDp,
                                            cornerRadiusDp = cornerRadiusDp,
                                            backgroundColor = currentBg.second.first,
                                            backgroundEndColor = currentBg.second.second,
                                            borderColor = borderColor.toArgb(),
                                            borderWidthDp = borderWidthDp,
                                            aspectRatioWidth = aspectRatioWidth,
                                            aspectRatioHeight = aspectRatioHeight,
                                            overlayText = overlayText,
                                            textColor = textColor.toArgb()
                                        )
                                        exportProgress = 50
                                        val bitmap = CollageExporter.renderCollageToBitmap(
                                            context = context,
                                            photos = photos,
                                            layoutType = selectedLayout,
                                            style = style,
                                            stickers = stickers,
                                            outputWidth = 1080
                                        )
                                        exportProgress = 80
                                        val result = CollageExporter.saveCollageImageToGallery(context, bitmap)
                                        exportProgress = 100
                                        exportResultFile = result.first
                                        exportResultUri = result.second
                                        isExporting = false
                                        Toast.makeText(context, "✅ Collage saved to Gallery!", Toast.LENGTH_LONG).show()
                                    } catch (e: Exception) {
                                        isExporting = false
                                        Toast.makeText(context, "Error saving: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF262638)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier.size(42.dp).clip(CircleShape).background(PrimaryPurple),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Image, contentDescription = null, tint = Color.White)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Download HD Photo (JPG)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Crystal clear high-res picture for Instagram / WhatsApp", color = Color.Gray, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Option 2: Download HD MP4 Video ("எம்பி4 ஆ என்னால டவுன்லோட் பண்ண முடியணும் எச்டில")
                        Card(
                            onClick = {
                                isExportVideo = true
                                isExporting = true
                                exportProgress = 10
                                coroutineScope.launch {
                                    try {
                                        val style = CollageStyle(
                                            spacingDp = spacingDp,
                                            cornerRadiusDp = cornerRadiusDp,
                                            backgroundColor = currentBg.second.first,
                                            backgroundEndColor = currentBg.second.second,
                                            borderColor = borderColor.toArgb(),
                                            borderWidthDp = borderWidthDp,
                                            aspectRatioWidth = aspectRatioWidth,
                                            aspectRatioHeight = aspectRatioHeight,
                                            overlayText = overlayText,
                                            textColor = textColor.toArgb()
                                        )
                                        val bitmap = CollageExporter.renderCollageToBitmap(
                                            context = context,
                                            photos = photos,
                                            layoutType = selectedLayout,
                                            style = style,
                                            stickers = stickers,
                                            outputWidth = 1080
                                        )
                                        val result = CollageExporter.exportCollageAsMp4Video(
                                            context = context,
                                            bitmap = bitmap,
                                            durationSeconds = 4,
                                            onProgress = { progress -> exportProgress = progress }
                                        )
                                        exportResultFile = result.first
                                        exportResultUri = result.second
                                        isExporting = false
                                        Toast.makeText(context, "✅ MP4 Video saved to Gallery!", Toast.LENGTH_LONG).show()
                                    } catch (e: Exception) {
                                        isExporting = false
                                        Toast.makeText(context, "Error exporting video: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF262638)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier.size(42.dp).clip(CircleShape).background(PrimaryBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Movie, contentDescription = null, tint = Color.White)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Download HD MP4 Video", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Animated HD MP4 video file straight to Gallery", color = Color.Gray, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (exportResultFile != null) {
                    Button(
                        onClick = {
                            showExportDialog = false
                            exportResultFile = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text("Done")
                    }
                }
            },
            dismissButton = {
                if (!isExporting && exportResultFile == null) {
                    TextButton(onClick = { showExportDialog = false }) {
                        Text("Cancel", color = Color.Gray)
                    }
                }
            },
            containerColor = Color(0xFF1E1E2C)
        )
    }
}

/**
 * Renders the collage cells according to the chosen CollageLayoutType
 */
@Composable
fun CollageLayoutContent(
    photos: List<CollagePhoto>,
    layoutType: CollageLayoutType,
    selectedIndex: Int,
    spacingDp: Float,
    cornerRadiusDp: Float,
    onSelectPhoto: (Int) -> Unit,
    onPanPhoto: (Int, Float, Float) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(spacingDp.dp)
    ) {
        when {
            photos.isEmpty() -> {}

            photos.size == 1 || layoutType == CollageLayoutType.FREEFORM -> {
                // Single or freeform collage
                Column(modifier = Modifier.fillMaxSize()) {
                    CollagePhotoCell(
                        photo = photos.first(),
                        isSelected = selectedIndex == 0,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.fillMaxSize(),
                        onClick = { onSelectPhoto(0) },
                        onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                    )
                }
            }

            layoutType == CollageLayoutType.SPLIT_HORIZONTAL && photos.size >= 2 -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    CollagePhotoCell(
                        photo = photos[0],
                        isSelected = selectedIndex == 0,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        onClick = { onSelectPhoto(0) },
                        onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                    )
                    CollagePhotoCell(
                        photo = photos[1],
                        isSelected = selectedIndex == 1,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        onClick = { onSelectPhoto(1) },
                        onPan = { dx, dy -> onPanPhoto(1, dx, dy) }
                    )
                }
            }

            layoutType == CollageLayoutType.SPLIT_VERTICAL && photos.size >= 2 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    CollagePhotoCell(
                        photo = photos[0],
                        isSelected = selectedIndex == 0,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        onClick = { onSelectPhoto(0) },
                        onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                    )
                    CollagePhotoCell(
                        photo = photos[1],
                        isSelected = selectedIndex == 1,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        onClick = { onSelectPhoto(1) },
                        onPan = { dx, dy -> onPanPhoto(1, dx, dy) }
                    )
                }
            }

            layoutType == CollageLayoutType.HERO_TOP_2_BOTTOM && photos.size >= 3 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    CollagePhotoCell(
                        photo = photos[0],
                        isSelected = selectedIndex == 0,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1.3f).fillMaxWidth(),
                        onClick = { onSelectPhoto(0) },
                        onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                    )
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        CollagePhotoCell(
                            photo = photos[1],
                            isSelected = selectedIndex == 1,
                            cornerRadiusDp = cornerRadiusDp,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            onClick = { onSelectPhoto(1) },
                            onPan = { dx, dy -> onPanPhoto(1, dx, dy) }
                        )
                        CollagePhotoCell(
                            photo = photos[2],
                            isSelected = selectedIndex == 2,
                            cornerRadiusDp = cornerRadiusDp,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            onClick = { onSelectPhoto(2) },
                            onPan = { dx, dy -> onPanPhoto(2, dx, dy) }
                        )
                    }
                }
            }

            layoutType == CollageLayoutType.HERO_BOTTOM_2_TOP && photos.size >= 3 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        CollagePhotoCell(
                            photo = photos[0],
                            isSelected = selectedIndex == 0,
                            cornerRadiusDp = cornerRadiusDp,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            onClick = { onSelectPhoto(0) },
                            onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                        )
                        CollagePhotoCell(
                            photo = photos[1],
                            isSelected = selectedIndex == 1,
                            cornerRadiusDp = cornerRadiusDp,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            onClick = { onSelectPhoto(1) },
                            onPan = { dx, dy -> onPanPhoto(1, dx, dy) }
                        )
                    }
                    CollagePhotoCell(
                        photo = photos[2],
                        isSelected = selectedIndex == 2,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1.3f).fillMaxWidth(),
                        onClick = { onSelectPhoto(2) },
                        onPan = { dx, dy -> onPanPhoto(2, dx, dy) }
                    )
                }
            }

            layoutType == CollageLayoutType.THREE_COLUMNS && photos.size >= 3 -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    for (i in 0 until 3) {
                        CollagePhotoCell(
                            photo = photos[i],
                            isSelected = selectedIndex == i,
                            cornerRadiusDp = cornerRadiusDp,
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            onClick = { onSelectPhoto(i) },
                            onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                        )
                    }
                }
            }

            layoutType == CollageLayoutType.HERO_LEFT_3_RIGHT && photos.size >= 4 -> {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    CollagePhotoCell(
                        photo = photos[0],
                        isSelected = selectedIndex == 0,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1.5f).fillMaxHeight(),
                        onClick = { onSelectPhoto(0) },
                        onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                    )
                    Column(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        for (i in 1..3) {
                            CollagePhotoCell(
                                photo = photos[i],
                                selectedIndex == i,
                                cornerRadiusDp = cornerRadiusDp,
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                onClick = { onSelectPhoto(i) },
                                onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                            )
                        }
                    }
                }
            }

            layoutType == CollageLayoutType.HERO_TOP_3_BOTTOM && photos.size >= 4 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    CollagePhotoCell(
                        photo = photos[0],
                        isSelected = selectedIndex == 0,
                        cornerRadiusDp = cornerRadiusDp,
                        modifier = Modifier.weight(1.5f).fillMaxWidth(),
                        onClick = { onSelectPhoto(0) },
                        onPan = { dx, dy -> onPanPhoto(0, dx, dy) }
                    )
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        for (i in 1..3) {
                            CollagePhotoCell(
                                photo = photos[i],
                                isSelected = selectedIndex == i,
                                cornerRadiusDp = cornerRadiusDp,
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { onSelectPhoto(i) },
                                onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                            )
                        }
                    }
                }
            }

            layoutType == CollageLayoutType.SIX_GRID && photos.size >= 6 -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        for (i in 0 until 3) {
                            CollagePhotoCell(
                                photo = photos[i],
                                isSelected = selectedIndex == i,
                                cornerRadiusDp = cornerRadiusDp,
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { onSelectPhoto(i) },
                                onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        for (i in 3 until 6) {
                            CollagePhotoCell(
                                photo = photos[i],
                                isSelected = selectedIndex == i,
                                cornerRadiusDp = cornerRadiusDp,
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { onSelectPhoto(i) },
                                onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                            )
                        }
                    }
                }
            }

            else -> {
                // Default 2x2 or 4-cell layout (works cleanly for 2, 3, 4, 5+ photos)
                val halfCount = (photos.size + 1) / 2
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(spacingDp.dp)
                ) {
                    // Row 1
                    Row(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                    ) {
                        val row1Count = if (photos.size == 3) 1 else 2
                        for (i in 0 until minOf(row1Count, photos.size)) {
                            CollagePhotoCell(
                                photo = photos[i],
                                isSelected = selectedIndex == i,
                                cornerRadiusDp = cornerRadiusDp,
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                                onClick = { onSelectPhoto(i) },
                                onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                            )
                        }
                    }
                    // Row 2
                    if (photos.size > 1) {
                        Row(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(spacingDp.dp)
                        ) {
                            val startIdx = if (photos.size == 3) 1 else 2
                            val endIdx = minOf(photos.size, if (photos.size == 3) 3 else 4)
                            for (i in startIdx until endIdx) {
                                CollagePhotoCell(
                                    photo = photos[i],
                                    isSelected = selectedIndex == i,
                                    cornerRadiusDp = cornerRadiusDp,
                                    modifier = Modifier.weight(1f).fillMaxHeight(),
                                    onClick = { onSelectPhoto(i) },
                                    onPan = { dx, dy -> onPanPhoto(i, dx, dy) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Individual Photo Cell in the collage
 */
@Composable
fun CollagePhotoCell(
    photo: CollagePhoto,
    isSelected: Boolean,
    cornerRadiusDp: Float,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onPan: (Float, Float) -> Unit
) {
    val shape = RoundedCornerShape(cornerRadiusDp.dp)

    Box(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFF1F1F2E))
            .then(
                if (isSelected) {
                    Modifier.border(2.5.dp, PrimaryBlue, shape)
                } else Modifier
            )
            .clickable(onClick = onClick)
            .pointerInput(photo.id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onPan(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        AsyncImage(
            model = photo.uri,
            contentDescription = "Collage Photo",
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = photo.scale * (if (photo.isFlipped) -1f else 1f)
                    scaleY = photo.scale
                    rotationZ = photo.rotation
                    translationX = photo.offsetX
                    translationY = photo.offsetY
                },
            contentScale = ContentScale.Crop
        )

        // Selected indicator badge
        if (isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(PrimaryBlue),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }
    }
}

/**
 * Mini Schematic Icon for the Layout Cards
 */
@Composable
fun MiniLayoutPreview(layout: CollageLayoutType, isSelected: Boolean) {
    val borderColor = if (isSelected) PrimaryPurple else Color.Gray
    val cellColor = if (isSelected) PrimaryPurple.copy(alpha = 0.5f) else Color.DarkGray

    Box(
        modifier = Modifier
            .size(36.dp)
            .border(1.dp, borderColor, RoundedCornerShape(4.dp))
            .padding(2.dp)
    ) {
        when (layout) {
            CollageLayoutType.SPLIT_HORIZONTAL -> {
                Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                }
            }
            CollageLayoutType.SPLIT_VERTICAL -> {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth().background(cellColor))
                    Box(modifier = Modifier.weight(1f).fillMaxWidth().background(cellColor))
                }
            }
            CollageLayoutType.GRID_2X2 -> {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    }
                    Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    }
                }
            }
            CollageLayoutType.HERO_TOP_2_BOTTOM -> {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(modifier = Modifier.weight(1.2f).fillMaxWidth().background(cellColor))
                    Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    }
                }
            }
            CollageLayoutType.HERO_LEFT_3_RIGHT -> {
                Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(modifier = Modifier.weight(1.2f).fillMaxHeight().background(cellColor))
                    Column(modifier = Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxWidth().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxWidth().background(cellColor))
                    }
                }
            }
            CollageLayoutType.THREE_COLUMNS -> {
                Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                }
            }
            CollageLayoutType.SIX_GRID -> {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    }
                    Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(cellColor))
                    }
                }
            }
            else -> {
                Box(modifier = Modifier.fillMaxSize().background(cellColor))
            }
        }
    }
}

fun getRecommendedLayout(count: Int): CollageLayoutType {
    return when (count) {
        1 -> CollageLayoutType.FREEFORM
        2 -> CollageLayoutType.SPLIT_HORIZONTAL
        3 -> CollageLayoutType.HERO_TOP_2_BOTTOM
        4 -> CollageLayoutType.GRID_2X2
        5 -> CollageLayoutType.FIVE_MOSAIC
        6 -> CollageLayoutType.SIX_GRID
        else -> CollageLayoutType.GRID_2X2
    }
}

/**
 * Creates 4 high-quality procedural sample pictures locally so the collage can be
 * instantly used even when testing on a clean device without camera gallery images.
 */
fun createSamplePhotoUris(context: Context): List<Uri> {
    val uris = mutableListOf<Uri>()
    val colors = listOf(
        Pair(0xFF2980B9.toInt(), "Beach Sunset"),
        Pair(0xFF27AE60.toInt(), "Mountain Pine"),
        Pair(0xFF8E44AD.toInt(), "Urban Neon"),
        Pair(0xFFD35400.toInt(), "Golden Hour")
    )

    val cacheDir = File(context.cacheDir, "sample_photos")
    if (!cacheDir.exists()) cacheDir.mkdirs()

    colors.forEachIndexed { index, (color, title) ->
        val file = File(cacheDir, "sample_${index + 1}.jpg")
        if (!file.exists()) {
            val bitmap = Bitmap.createBitmap(720, 720, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(color)

            // Draw decorative circle and title
            val paintCircle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = android.graphics.Color.WHITE
                alpha = 40
            }
            canvas.drawCircle(360f, 360f, 220f, paintCircle)

            val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = android.graphics.Color.WHITE
                textSize = 52f
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(title, 360f, 375f, paintText)

            val paintSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = android.graphics.Color.WHITE
                textSize = 32f
                alpha = 180
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("Photo ${index + 1}", 360f, 440f, paintSub)

            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        uris.add(uri)
    }

    return uris
}
