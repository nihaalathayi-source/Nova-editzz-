package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.zIndex
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.AppDatabase
import com.example.data.ProjectEntity
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.SurfaceVariantDark
import com.example.utils.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

enum class EditorTab {
    NONE, TRIM, TRANSITION, VFX, GRAPHICS, VOICEOVER, AUDIO, TEXT, FILTERS, SPEED, RATIO
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEditorScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var editState by remember { mutableStateOf(VideoEditState()) }
    var activeTab by remember { mutableStateOf(EditorTab.NONE) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var currentItemIndex by remember { mutableIntStateOf(0) }
    var totalSequenceDurationMs by remember { mutableLongStateOf(0L) }
    var showExportDialog by remember { mutableStateOf(false) }
    var draggedClipIndex by remember { mutableStateOf<Int?>(null) }
    var dragAccumulatedOffset by remember { mutableFloatStateOf(0f) }

    val videoExporter = remember { VideoExporter(context) }
    val exportState by videoExporter.exportState.collectAsState()
    val exportProgress by videoExporter.exportProgress.collectAsState()

    val audioRecorder = remember { AudioVoiceoverRecorder(context) }
    val isRecordingVoiceover by audioRecorder.isRecording.collectAsState()
    var recordingTimerSeconds by remember { mutableIntStateOf(0) }

    val db = remember { AppDatabase.getDatabase(context) }

    // Main Video ExoPlayer
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = false
        }
    }

    // Secondary Audio Player for Voiceover & Music preview
    val extraAudioPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = false
        }
    }

    // Helper: vibrate briefly on edits
    fun vibrateFeedback() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    // Helper: Retrieve video duration from Uri
    fun getVideoDuration(uri: Uri): Long {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            retriever.release()
            durationStr?.toLongOrNull() ?: 5000L
        } catch (_: Exception) {
            5000L
        }
    }

    // Function to reload media items into ExoPlayer based on clips
    fun refreshPlayerClips(clips: List<VideoClip>, seekToClipIndex: Int = 0, seekToMs: Long = 0L) {
        if (clips.isEmpty()) {
            exoPlayer.clearMediaItems()
            return
        }
        val mediaItems = clips.map { clip ->
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.startMs)
            if (clip.endMs > 0) {
                clipping.setEndPositionMs(clip.endMs)
            }
            MediaItem.Builder()
                .setUri(clip.uri)
                .setMediaId(clip.id)
                .setClippingConfiguration(clipping.build())
                .build()
        }
        exoPlayer.setMediaItems(mediaItems, seekToClipIndex, seekToMs)
        exoPlayer.prepare()
    }

    // Multi-video picker launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val newClips = uris.mapIndexed { idx, uri ->
                val duration = getVideoDuration(uri)
                VideoClip(
                    uri = uri,
                    title = "Clip ${editState.clips.size + idx + 1}",
                    startMs = 0L,
                    endMs = duration,
                    durationMs = duration
                )
            }
            val updatedClips = editState.clips + newClips
            val selectedId = editState.selectedClipId ?: updatedClips.firstOrNull()?.id
            editState = editState.copy(clips = updatedClips, selectedClipId = selectedId)
            refreshPlayerClips(updatedClips)
            Toast.makeText(context, "${uris.size} video(s) added to timeline", Toast.LENGTH_SHORT).show()
        }
    }

    // Background Audio Picker launcher
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            editState = editState.copy(
                musicUri = uri,
                musicName = "Custom Music Track"
            )
            extraAudioPlayer.setMediaItem(MediaItem.fromUri(uri))
            extraAudioPlayer.prepare()
            Toast.makeText(context, "Music track added!", Toast.LENGTH_SHORT).show()
        }
    }

    // Audio recording permission launcher
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
        if (isGranted) {
            Toast.makeText(context, "Microphone permission granted! Ready to record voiceover", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Microphone permission is required for voiceover", Toast.LENGTH_LONG).show()
        }
    }

    // Launch initial picker if empty
    LaunchedEffect(Unit) {
        if (editState.clips.isEmpty()) {
            videoPickerLauncher.launch(
                androidx.activity.result.PickVisualMediaRequest(
                    ActivityResultContracts.PickVisualMedia.VideoOnly
                )
            )
        }
    }

    // Handle back button
    BackHandler {
        if (activeTab != EditorTab.NONE) {
            activeTab = EditorTab.NONE
        } else {
            onNavigateBack()
        }
    }

    // Apply playback speed & volume to ExoPlayer
    LaunchedEffect(editState.playbackSpeed) {
        exoPlayer.setPlaybackSpeed(editState.playbackSpeed)
    }

    LaunchedEffect(editState.isMuted) {
        exoPlayer.volume = if (editState.isMuted) 0f else 1f
    }

    // Sync extra audio preview (Voiceover / Music) with playback
    LaunchedEffect(editState.voiceoverUri, editState.musicUri) {
        val audioUri = editState.voiceoverUri ?: editState.musicUri
        if (audioUri != null) {
            extraAudioPlayer.setMediaItem(MediaItem.fromUri(audioUri))
            extraAudioPlayer.prepare()
            extraAudioPlayer.volume = if (editState.voiceoverUri != null) editState.voiceoverVolume else editState.musicVolume
        } else {
            extraAudioPlayer.clearMediaItems()
        }
    }

    // Polling player timeline position
    LaunchedEffect(isPlaying) {
        while (isActive) {
            if (exoPlayer.playbackState == ExoPlayer.STATE_READY) {
                currentPositionMs = exoPlayer.currentPosition
                currentItemIndex = exoPlayer.currentMediaItemIndex
                totalSequenceDurationMs = editState.clips.sumOf { it.effectiveDurationMs }
            }
            if (exoPlayer.playbackState == ExoPlayer.STATE_ENDED) {
                isPlaying = false
                extraAudioPlayer.pause()
            }
            delay(100)
        }
    }

    // Voiceover timer counter
    LaunchedEffect(isRecordingVoiceover) {
        recordingTimerSeconds = 0
        while (isRecordingVoiceover && isActive) {
            delay(1000)
            recordingTimerSeconds++
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
            extraAudioPlayer.release()
            if (isRecordingVoiceover) {
                audioRecorder.cancelRecording()
            }
        }
    }

    // Quick Split Function: Splits active clip into two at current playhead position
    fun performSplit() {
        val clips = editState.clips
        if (clips.isEmpty()) return

        val clipIndex = currentItemIndex.coerceIn(0, clips.size - 1)
        val clip = clips[clipIndex]

        val relativePlayheadMs = exoPlayer.currentPosition
        val splitAbsoluteMs = clip.startMs + relativePlayheadMs
        val clipEnd = if (clip.endMs > 0) clip.endMs else clip.durationMs

        if (splitAbsoluteMs > clip.startMs + 300 && splitAbsoluteMs < clipEnd - 300) {
            val clipPart1 = clip.copy(
                id = java.util.UUID.randomUUID().toString(),
                title = "${clip.title} (Part 1)",
                startMs = clip.startMs,
                endMs = splitAbsoluteMs,
                durationMs = clip.durationMs
            )
            val clipPart2 = clip.copy(
                id = java.util.UUID.randomUUID().toString(),
                title = "${clip.title} (Part 2)",
                startMs = splitAbsoluteMs,
                endMs = clipEnd,
                durationMs = clip.durationMs
            )

            val updatedClips = clips.toMutableList()
            updatedClips.removeAt(clipIndex)
            updatedClips.add(clipIndex, clipPart1)
            updatedClips.add(clipIndex + 1, clipPart2)

            editState = editState.copy(
                clips = updatedClips,
                selectedClipId = clipPart2.id
            )

            vibrateFeedback()
            refreshPlayerClips(updatedClips, seekToClipIndex = clipIndex + 1, seekToMs = 0L)
            Toast.makeText(
                context,
                "✂️ Clip Split into 2 parts at ${formatTimeMs(splitAbsoluteMs)}!",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(context, "Move playhead inside the clip to split", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("NovaEdit Studio", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            "${editState.clips.size} clips • ${formatTimeMs(totalSequenceDurationMs)} • ${editState.exportQuality.title}",
                            fontSize = 11.sp,
                            color = Color.LightGray
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    // Quick Split action in header for instant access
                    IconButton(
                        onClick = { performSplit() },
                        enabled = editState.clips.isNotEmpty()
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = "Split", tint = PrimaryBlue)
                    }

                    // Export HD MP4 button opens HD Export Dialog
                    Button(
                        onClick = {
                            if (editState.clips.isNotEmpty()) {
                                showExportDialog = true
                            } else {
                                Toast.makeText(context, "Add at least one video first", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export HD", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black)
            )
        },
        containerColor = Color.Black
    ) { paddingValues ->

        // Listen for export finish and save to Room
        LaunchedEffect(exportState) {
            if (exportState is VideoExporter.ExportState.Success) {
                val success = exportState as VideoExporter.ExportState.Success
                coroutineScope.launch {
                    try {
                        db.projectDao().insertProject(
                            ProjectEntity(
                                name = success.displayName,
                                projectType = "VIDEO",
                                mediaUris = success.outputPath,
                                thumbnailUri = null
                            )
                        )
                    } catch (_: Exception) {}
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // ==================== 1. VIDEO PREVIEW AREA ====================
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (editState.clips.isNotEmpty()) {
                        val ratioModifier = if (editState.aspectRatio.ratio != null) {
                            Modifier
                                .aspectRatio(editState.aspectRatio.ratio!!)
                                .fillMaxHeight()
                        } else {
                            Modifier.fillMaxSize()
                        }

                        // Active clip transition calculations for live playback
                        val activeClip = editState.clips.getOrNull(currentItemIndex)
                        val clipDurationMs = activeClip?.effectiveDurationMs ?: 0L
                        val transDurationMs = activeClip?.transitionDurationMs ?: 800L
                        val currentTransition = activeClip?.transition ?: ClipTransition.NONE

                        val isNearClipEnd = currentTransition != ClipTransition.NONE &&
                            clipDurationMs > 0 &&
                            currentPositionMs >= (clipDurationMs - transDurationMs)

                        val transProgress = if (isNearClipEnd && transDurationMs > 0) {
                            ((currentPositionMs - (clipDurationMs - transDurationMs)).toFloat() / transDurationMs).coerceIn(0f, 1f)
                        } else 0f

                        // Animation controllers for VFX and Text Animations
                        val infiniteTransition = rememberInfiniteTransition(label = "videoFx")

                        val glitchJitter by infiniteTransition.animateFloat(
                            initialValue = -5f,
                            targetValue = 5f,
                            animationSpec = infiniteRepeatable(tween(80, easing = LinearEasing), RepeatMode.Reverse),
                            label = "jitter"
                        )

                        val textBounceScale by infiniteTransition.animateFloat(
                            initialValue = 0.88f,
                            targetValue = 1.16f,
                            animationSpec = infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                            label = "bounce"
                        )

                        val textPulseScale by infiniteTransition.animateFloat(
                            initialValue = 0.95f,
                            targetValue = 1.15f,
                            animationSpec = infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                            label = "pulse"
                        )

                        val textFadeAlpha by infiniteTransition.animateFloat(
                            initialValue = 0.25f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                            label = "fade"
                        )

                        val neonGlowAlpha by infiniteTransition.animateFloat(
                            initialValue = 0.4f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(tween(500, easing = LinearEasing), RepeatMode.Reverse),
                            label = "neon"
                        )

                        val typewriterProgress by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = (editState.customText.length + 1).toFloat(),
                            animationSpec = infiniteRepeatable(
                                tween((editState.customText.length * 150).coerceAtLeast(1200), easing = LinearEasing),
                                RepeatMode.Restart
                            ),
                            label = "typewriter"
                        )

                        val textSlideUpY by infiniteTransition.animateFloat(
                            initialValue = 28f,
                            targetValue = 0f,
                            animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Restart),
                            label = "slideUp"
                        )

                        val textGlitchX by infiniteTransition.animateFloat(
                            initialValue = -4f,
                            targetValue = 4f,
                            animationSpec = infiniteRepeatable(tween(60, easing = LinearEasing), RepeatMode.Reverse),
                            label = "glitchText"
                        )

                        val playerScaleX = when (currentTransition) {
                            ClipTransition.ZOOM_IN -> 1.0f + (transProgress * 0.35f)
                            else -> 1.0f
                        }
                        val playerTranslationX = when (currentTransition) {
                            ClipTransition.SLIDE_LEFT -> -transProgress * 500f
                            ClipTransition.SLIDE_RIGHT -> transProgress * 500f
                            else -> 0f
                        }
                        val playerAlpha = when (currentTransition) {
                            ClipTransition.CROSSFADE -> 1.0f - (transProgress * 0.6f)
                            else -> 1.0f
                        }

                        Box(
                            modifier = ratioModifier,
                            contentAlignment = Alignment.Center
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        player = exoPlayer
                                        useController = false
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        scaleX = playerScaleX
                                        scaleY = playerScaleX
                                        translationX = playerTranslationX
                                        alpha = playerAlpha
                                    }
                            )

                            // Video zoom/scale indicator if active
                            if (editState.isCropped || editState.videoScale != 1.0f) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(8.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Zoom ${(editState.videoScale * 100).toInt()}%", color = Color.White, fontSize = 10.sp)
                                }
                            }

                            // ==================== LIVE TRANSITIONS OVERLAYS ====================
                            if (currentTransition == ClipTransition.FADE_BLACK && transProgress > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = transProgress))
                                )
                            } else if (currentTransition == ClipTransition.FADE_WHITE && transProgress > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White.copy(alpha = (transProgress * 0.9f).coerceIn(0f, 1f)))
                                )
                            } else if (currentTransition == ClipTransition.WIPE && transProgress > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(transProgress)
                                        .fillMaxHeight()
                                        .align(Alignment.CenterStart)
                                        .background(Color.Black)
                                )
                            }

                            // ==================== COLOR FILTERS OVERLAYS ====================
                            when (editState.filter) {
                                EditorFilter.GRAYSCALE -> {
                                    Box(modifier = Modifier.fillMaxSize().background(Color(0x33444444)))
                                }
                                EditorFilter.SEPIA -> {
                                    Box(modifier = Modifier.fillMaxSize().background(Color(0x44704214)))
                                }
                                EditorFilter.WARM -> {
                                    Box(modifier = Modifier.fillMaxSize().background(Color(0x33FFB300)))
                                }
                                EditorFilter.COOL -> {
                                    Box(modifier = Modifier.fillMaxSize().background(Color(0x3300E5FF)))
                                }
                                EditorFilter.INVERT -> {
                                    Box(modifier = Modifier.fillMaxSize().background(Color(0x33E91E63)))
                                }
                                else -> {}
                            }

                            // ==================== LIVE VFX EFFECTS OVERLAYS ====================
                            when (editState.vfx) {
                                VideoVfx.GLITCH -> {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val bandHeight = size.height / 10f
                                        for (i in 0 until 5) {
                                            val y = (i * bandHeight * 2f + glitchJitter * 8f) % size.height
                                            drawRect(
                                                color = if (i % 2 == 0) Color.Cyan.copy(alpha = 0.25f) else Color.Magenta.copy(alpha = 0.25f),
                                                topLeft = Offset(glitchJitter * (i + 1), y),
                                                size = Size(size.width, bandHeight * 0.5f)
                                            )
                                        }
                                    }
                                }
                                VideoVfx.VHS_RETRO -> {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val lineSpacing = 7.dp.toPx()
                                        var y = 0f
                                        while (y < size.height) {
                                            drawLine(
                                                color = Color.Black.copy(alpha = 0.28f),
                                                start = Offset(0f, y),
                                                end = Offset(size.width, y),
                                                strokeWidth = 1.5f
                                            )
                                            y += lineSpacing
                                        }
                                    }
                                    Box(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                                        Text(
                                            "PLAY ▶ ${formatTimeMs(currentPositionMs)}\nSP 4:3 HI-FI",
                                            color = Color(0xFF00E676),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.align(Alignment.TopStart)
                                        )
                                    }
                                }
                                VideoVfx.FILM_GRAIN -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.radialGradient(
                                                    colors = listOf(Color.Transparent, Color(0x992B1810), Color(0xDD000000))
                                                )
                                            )
                                    )
                                }
                                VideoVfx.RGB_SPLIT -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .border(2.dp, Color.Cyan.copy(alpha = 0.6f))
                                            .padding(3.dp)
                                            .border(2.dp, Color.Magenta.copy(alpha = 0.6f))
                                    )
                                }
                                VideoVfx.NEON_GLOW -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .border(
                                                width = 3.dp,
                                                brush = Brush.sweepGradient(listOf(Color.Cyan, Color.Magenta, Color.Yellow, Color.Cyan)),
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                    )
                                }
                                VideoVfx.VIGNETTE -> {
                                    Column(modifier = Modifier.fillMaxSize()) {
                                        Box(modifier = Modifier.fillMaxWidth().height(16.dp).background(Color.Black))
                                        Spacer(modifier = Modifier.weight(1f))
                                        Box(modifier = Modifier.fillMaxWidth().height(16.dp).background(Color.Black))
                                    }
                                }
                                VideoVfx.FLASH -> {
                                    if (isPlaying && (currentPositionMs / 450L) % 2L == 0L) {
                                        Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.35f)))
                                    }
                                }
                                VideoVfx.SPARKLE -> {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        Text("✨", fontSize = 24.sp, modifier = Modifier.align(Alignment.TopStart).padding(20.dp))
                                        Text("⭐", fontSize = 20.sp, modifier = Modifier.align(Alignment.TopEnd).padding(30.dp))
                                        Text("💖", fontSize = 22.sp, modifier = Modifier.align(Alignment.BottomStart).padding(24.dp))
                                        Text("✨", fontSize = 26.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp))
                                    }
                                }
                                else -> {}
                            }

                            // ==================== ANIMATED TEXT OVERLAY PREVIEW ====================
                            if (editState.customText.isNotBlank()) {
                                val textAlignment = when (editState.textPosition) {
                                    "TOP" -> Alignment.TopCenter
                                    "CENTER" -> Alignment.Center
                                    else -> Alignment.BottomCenter
                                }

                                val textFontFamily = when (editState.textFont) {
                                    TextFont.SERIF -> FontFamily.Serif
                                    TextFont.MONO -> FontFamily.Monospace
                                    TextFont.CURSIVE -> FontFamily.Cursive
                                    else -> FontFamily.Default
                                }
                                val textFontWeight = if (editState.textFont == TextFont.BOLD_HEAVY) FontWeight.ExtraBold else FontWeight.Bold

                                val textScaleMultiplier = when (editState.textAnimation) {
                                    TextAnimation.BOUNCE -> textBounceScale
                                    TextAnimation.PULSE -> textPulseScale
                                    else -> 1.0f
                                }
                                val textAlphaVal = when (editState.textAnimation) {
                                    TextAnimation.FADE_IN -> textFadeAlpha
                                    else -> 1.0f
                                }
                                val textOffsetY = when (editState.textAnimation) {
                                    TextAnimation.SLIDE_UP -> textSlideUpY.dp
                                    else -> 0.dp
                                }
                                val textOffsetX = when (editState.textAnimation) {
                                    TextAnimation.GLITCH -> textGlitchX.dp
                                    else -> 0.dp
                                }

                                val visibleChars = typewriterProgress.toInt().coerceIn(0, editState.customText.length)
                                val textToShow = if (editState.textAnimation == TextAnimation.TYPEWRITER) {
                                    editState.customText.take(visibleChars) + if (visibleChars < editState.customText.length) "▌" else ""
                                } else {
                                    editState.customText
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(18.dp),
                                    contentAlignment = textAlignment
                                ) {
                                    Surface(
                                        color = if (editState.textBackground) Color.Black.copy(alpha = 0.72f) else Color.Transparent,
                                        shape = RoundedCornerShape(10.dp),
                                        border = if (editState.textAnimation == TextAnimation.NEON_GLOW) {
                                            androidx.compose.foundation.BorderStroke(2.dp, Color.Cyan.copy(alpha = neonGlowAlpha))
                                        } else if (editState.textBackground) {
                                            androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.35f))
                                        } else null,
                                        modifier = Modifier
                                            .offset(x = textOffsetX, y = textOffsetY)
                                            .graphicsLayer {
                                                scaleX = textScaleMultiplier
                                                scaleY = textScaleMultiplier
                                                alpha = textAlphaVal
                                            }
                                            .clickable { activeTab = EditorTab.TEXT }
                                    ) {
                                        Text(
                                            text = textToShow,
                                            color = Color(editState.textColor),
                                            fontSize = (18 * editState.textScale).sp,
                                            fontWeight = textFontWeight,
                                            fontFamily = textFontFamily,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            // ==================== DYNAMIC GRAPHIC / BADGE OVERLAY PREVIEW ====================
                            if (editState.graphicItem != null) {
                                val graphic = editState.graphicItem!!
                                val alignment = when (graphic.position) {
                                    "TOP_LEFT" -> Alignment.TopStart
                                    "TOP_RIGHT" -> Alignment.TopEnd
                                    "TOP_CENTER" -> Alignment.TopCenter
                                    "CENTER" -> Alignment.Center
                                    "BOTTOM_LEFT" -> Alignment.BottomStart
                                    "BOTTOM_RIGHT" -> Alignment.BottomEnd
                                    else -> Alignment.TopEnd
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(14.dp),
                                    contentAlignment = alignment
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .graphicsLayer {
                                                scaleX = graphic.scale
                                                scaleY = graphic.scale
                                                rotationZ = graphic.rotationDeg
                                                alpha = graphic.opacity
                                            }
                                            .clickable { activeTab = EditorTab.GRAPHICS }
                                    ) {
                                        when (graphic.category) {
                                            "BADGE" -> {
                                                Surface(
                                                    color = Color(0xFFE50914),
                                                    shape = RoundedCornerShape(8.dp),
                                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.8f))
                                                ) {
                                                    Text(
                                                        text = graphic.textOrEmoji,
                                                        color = Color.White,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                            "LOWER_THIRD" -> {
                                                Surface(
                                                    color = Color(0xFF0F172A).copy(alpha = 0.9f),
                                                    shape = RoundedCornerShape(6.dp),
                                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue)
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                                    ) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(8.dp)
                                                                .clip(CircleShape)
                                                                .background(Color.Red)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(
                                                            text = graphic.textOrEmoji,
                                                            color = Color.White,
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }
                                            }
                                            else -> { // EMOJI
                                                Surface(
                                                    color = Color.Black.copy(alpha = 0.55f),
                                                    shape = RoundedCornerShape(12.dp),
                                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue)
                                                ) {
                                                    Text(
                                                        text = graphic.textOrEmoji,
                                                        fontSize = 28.sp,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Live Voiceover Recording Indicator
                            if (isRecordingVoiceover) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .padding(16.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(Color.Red.copy(alpha = 0.85f))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(Color.White)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            "REC ${formatSeconds(recordingTimerSeconds)}",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Active badges (Voiceover / Ratio / Filter)
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (editState.aspectRatio != VideoAspectRatio.ORIGINAL) {
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.7f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            editState.aspectRatio.title,
                                            color = PrimaryBlue,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (editState.voiceoverUri != null) {
                                    Surface(
                                        color = Color(0xFF1E88E5).copy(alpha = 0.85f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            "🎙️ Mic",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                Icons.Default.VideoLibrary,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No Videos in Timeline", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Import videos to start cutting, splitting, and scaling graphics", color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = {
                                    videoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.VideoOnly
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Choose Videos")
                            }
                        }
                    }
                }

                // ==================== 2. TIMELINE & SCRUBBER ====================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceVariantDark)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    // Time Labels & Playback Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${formatTimeMs(currentPositionMs)} / ${formatTimeMs(totalSequenceDurationMs.coerceAtLeast(exoPlayer.duration))}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val newPos = (exoPlayer.currentPosition - 1000).coerceAtLeast(0)
                                    exoPlayer.seekTo(newPos)
                                    extraAudioPlayer.seekTo(newPos)
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Replay, contentDescription = "-1s", tint = Color.White, modifier = Modifier.size(20.dp))
                            }

                            // Big Play / Pause Button
                            IconButton(
                                onClick = {
                                    isPlaying = !isPlaying
                                    exoPlayer.playWhenReady = isPlaying
                                    if (isPlaying) {
                                        extraAudioPlayer.seekTo(exoPlayer.currentPosition)
                                        extraAudioPlayer.play()
                                    } else {
                                        extraAudioPlayer.pause()
                                    }
                                },
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryBlue)
                            ) {
                                Icon(
                                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = Color.Black,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            IconButton(
                                onClick = {
                                    val newPos = (exoPlayer.currentPosition + 1000).coerceAtMost(exoPlayer.duration)
                                    exoPlayer.seekTo(newPos)
                                    extraAudioPlayer.seekTo(newPos)
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Forward10, contentDescription = "+1s", tint = Color.White, modifier = Modifier.size(20.dp))
                            }

                            // Direct Split button on timeline bar
                            OutlinedButton(
                                onClick = { performSplit() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.ContentCut, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Split", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }

                    // Timeline Scrubbing Slider
                    val playerDuration = exoPlayer.duration.coerceAtLeast(1L)
                    Slider(
                        value = currentPositionMs.toFloat().coerceIn(0f, playerDuration.toFloat()),
                        onValueChange = { newPos ->
                            currentPositionMs = newPos.toLong()
                            exoPlayer.seekTo(newPos.toLong())
                            extraAudioPlayer.seekTo(newPos.toLong())
                        },
                        valueRange = 0f..playerDuration.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = PrimaryBlue,
                            activeTrackColor = PrimaryBlue,
                            inactiveTrackColor = Color.DarkGray
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(26.dp)
                    )

                    // Multi-Clip Sequence Strip (Thumbnails, Delete & Reorder)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        editState.clips.forEachIndexed { index, clip ->
                            val isSelected = clip.id == editState.selectedClipId
                            val isCurrentlyPlaying = index == currentItemIndex
                            val isBeingDragged = draggedClipIndex == index
                            val offsetX = if (isBeingDragged) dragAccumulatedOffset else 0f

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isBeingDragged) PrimaryBlue.copy(alpha = 0.55f) else if (isSelected) PrimaryBlue.copy(alpha = 0.35f) else Color(0xFF262626),
                                shadowElevation = if (isBeingDragged) 10.dp else 0.dp,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isBeingDragged) 2.dp else if (isSelected) 2.dp else if (isCurrentlyPlaying) 1.dp else 0.dp,
                                    color = if (isBeingDragged) Color.Cyan else if (isSelected) PrimaryBlue else if (isCurrentlyPlaying) Color.Yellow else Color.Transparent
                                ),
                                modifier = Modifier
                                    .zIndex(if (isBeingDragged) 10f else 1f)
                                    .graphicsLayer {
                                        translationX = offsetX
                                        scaleX = if (isBeingDragged) 1.08f else 1.0f
                                        scaleY = if (isBeingDragged) 1.08f else 1.0f
                                    }
                                    .clickable {
                                        editState = editState.copy(selectedClipId = clip.id)
                                        exoPlayer.seekTo(index, 0L)
                                        extraAudioPlayer.seekTo(0L)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // Drag-and-drop handle
                                    Box(
                                        modifier = Modifier
                                            .pointerInput(clip.id, editState.clips.size) {
                                                detectHorizontalDragGestures(
                                                    onDragStart = {
                                                        draggedClipIndex = index
                                                        dragAccumulatedOffset = 0f
                                                        vibrateFeedback()
                                                    },
                                                    onDragEnd = {
                                                        draggedClipIndex = null
                                                        dragAccumulatedOffset = 0f
                                                    },
                                                    onDragCancel = {
                                                        draggedClipIndex = null
                                                        dragAccumulatedOffset = 0f
                                                    },
                                                    onHorizontalDrag = { change, dragAmount ->
                                                        change.consume()
                                                        dragAccumulatedOffset += dragAmount
                                                        val currentIndex = draggedClipIndex ?: index
                                                        // Swap forward if dragged right past threshold
                                                        if (dragAccumulatedOffset > 70f && currentIndex < editState.clips.size - 1) {
                                                            val mutable = editState.clips.toMutableList()
                                                            val item = mutable.removeAt(currentIndex)
                                                            mutable.add(currentIndex + 1, item)
                                                            editState = editState.copy(clips = mutable)
                                                            draggedClipIndex = currentIndex + 1
                                                            dragAccumulatedOffset = 0f
                                                            vibrateFeedback()
                                                            refreshPlayerClips(mutable, seekToClipIndex = currentIndex + 1)
                                                        }
                                                        // Swap backward if dragged left past threshold
                                                        else if (dragAccumulatedOffset < -70f && currentIndex > 0) {
                                                            val mutable = editState.clips.toMutableList()
                                                            val item = mutable.removeAt(currentIndex)
                                                            mutable.add(currentIndex - 1, item)
                                                            editState = editState.copy(clips = mutable)
                                                            draggedClipIndex = currentIndex - 1
                                                            dragAccumulatedOffset = 0f
                                                            vibrateFeedback()
                                                            refreshPlayerClips(mutable, seekToClipIndex = currentIndex - 1)
                                                        }
                                                    }
                                                )
                                            }
                                            .padding(2.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.DragIndicator,
                                            contentDescription = "Drag to reorder clip",
                                            tint = if (isBeingDragged) Color.Cyan else PrimaryBlue,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    Icon(
                                        Icons.Default.Movie,
                                        contentDescription = null,
                                        tint = if (isSelected) PrimaryBlue else Color.LightGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Column {
                                        Text(
                                            clip.title,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text(
                                            formatTimeMs(clip.effectiveDurationMs),
                                            color = Color.Gray,
                                            fontSize = 9.sp
                                        )
                                    }

                                    // Direct Clip Delete button on clip card
                                    IconButton(
                                        onClick = {
                                            val mutable = editState.clips.toMutableList()
                                            mutable.removeAt(index)
                                            val newSelected = mutable.firstOrNull()?.id
                                            editState = editState.copy(clips = mutable, selectedClipId = newSelected)
                                            refreshPlayerClips(mutable)
                                            vibrateFeedback()
                                            Toast.makeText(context, "🗑️ Clip deleted", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Delete Clip",
                                            tint = Color(0xFFFF5252),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }

                            // Interactive Transition node between adjacent clips
                            if (index < editState.clips.size - 1) {
                                val trans = clip.transition
                                val isTransActive = trans != ClipTransition.NONE
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isTransActive) PrimaryBlue.copy(alpha = 0.3f) else Color(0xFF1E293B),
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = 1.dp,
                                        color = if (isTransActive) PrimaryBlue else Color(0xFF475569)
                                    ),
                                    modifier = Modifier
                                        .clickable {
                                            editState = editState.copy(selectedClipId = clip.id)
                                            activeTab = EditorTab.TRANSITION
                                            vibrateFeedback()
                                        }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(trans.iconEmoji, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            if (isTransActive) trans.title else "Transition",
                                            color = if (isTransActive) PrimaryBlue else Color.LightGray,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Add Video Card in Timeline
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF1E293B),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.6f)),
                            modifier = Modifier.clickable {
                                videoPickerLauncher.launch(
                                    androidx.activity.result.PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.VideoOnly
                                    )
                                )
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add Video", tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Video", color = PrimaryBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Active Clip Actions Bar (Reorder / Duplicate / Clear)
                    val selectedClip = editState.clips.find { it.id == editState.selectedClipId }
                    if (selectedClip != null && editState.clips.isNotEmpty()) {
                        val clipIndex = editState.clips.indexOfFirst { it.id == selectedClip.id }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${selectedClip.title}",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Duplicate Clip
                                TextButton(
                                    onClick = {
                                        val duplicate = selectedClip.copy(
                                            id = java.util.UUID.randomUUID().toString(),
                                            title = "${selectedClip.title} (Copy)"
                                        )
                                        val mutable = editState.clips.toMutableList()
                                        mutable.add(clipIndex + 1, duplicate)
                                        editState = editState.copy(clips = mutable, selectedClipId = duplicate.id)
                                        refreshPlayerClips(mutable, seekToClipIndex = clipIndex + 1)
                                        Toast.makeText(context, "Clip duplicated", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Duplicate", fontSize = 11.sp, color = PrimaryBlue)
                                }

                                // Move Left
                                if (clipIndex > 0) {
                                    IconButton(
                                        onClick = {
                                            val mutable = editState.clips.toMutableList()
                                            val temp = mutable[clipIndex]
                                            mutable[clipIndex] = mutable[clipIndex - 1]
                                            mutable[clipIndex - 1] = temp
                                            editState = editState.copy(clips = mutable)
                                            refreshPlayerClips(mutable, seekToClipIndex = clipIndex - 1)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Move Left", tint = Color.LightGray, modifier = Modifier.size(14.dp))
                                    }
                                }

                                // Move Right
                                if (clipIndex < editState.clips.size - 1) {
                                    IconButton(
                                        onClick = {
                                            val mutable = editState.clips.toMutableList()
                                            val temp = mutable[clipIndex]
                                            mutable[clipIndex] = mutable[clipIndex + 1]
                                            mutable[clipIndex + 1] = temp
                                            editState = editState.copy(clips = mutable)
                                            refreshPlayerClips(mutable, seekToClipIndex = clipIndex + 1)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Move Right", tint = Color.LightGray, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // ==================== 3. TOOL CONFIGURATION PANEL ====================
                AnimatedVisibility(visible = activeTab != EditorTab.NONE) {
                    Surface(
                        color = Color(0xFF1E1E1E),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            // Sub-panel header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when (activeTab) {
                                        EditorTab.TRIM -> "✂️ Precision Trim Tool"
                                        EditorTab.TRANSITION -> "🔀 Transitions Between Clips (ட்ரான்சிஷன்)"
                                        EditorTab.VFX -> "✨ Visual Effects & VFX (விஎஃப்எக்ஸ்)"
                                        EditorTab.GRAPHICS -> "🎨 Graphics & Stickers (கிராபிக்ஸ் / பேட்ஜ்)"
                                        EditorTab.VOICEOVER -> "🎙️ Voiceover Studio"
                                        EditorTab.AUDIO -> "🎵 Audio & Background Music"
                                        EditorTab.TEXT -> "✍️ Animated Text & Captions (டெக்ஸ்ட் அனிமேஷன்)"
                                        EditorTab.FILTERS -> "🎨 Color Filters & FX"
                                        EditorTab.SPEED -> "⚡ Playback Speed"
                                        EditorTab.RATIO -> "📐 Format, Aspect Ratio & Zoom"
                                        else -> ""
                                    },
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                IconButton(
                                    onClick = { activeTab = EditorTab.NONE },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // TOOL CONTENT BASED ON TAB
                            when (activeTab) {
                                EditorTab.TRIM -> {
                                    TrimToolContent(
                                        clips = editState.clips,
                                        selectedClipId = editState.selectedClipId,
                                        currentPlayheadMs = exoPlayer.currentPosition,
                                        onUpdateClip = { updatedClip ->
                                            val updated = editState.clips.map { if (it.id == updatedClip.id) updatedClip else it }
                                            editState = editState.copy(clips = updated)
                                            val idx = updated.indexOfFirst { it.id == updatedClip.id }
                                            refreshPlayerClips(updated, seekToClipIndex = idx.coerceAtLeast(0), seekToMs = updatedClip.startMs)
                                        }
                                    )
                                }
                                EditorTab.TRANSITION -> {
                                    TransitionToolContent(
                                        clips = editState.clips,
                                        selectedClipId = editState.selectedClipId,
                                        onUpdateClip = { updatedClip ->
                                            val updated = editState.clips.map { if (it.id == updatedClip.id) updatedClip else it }
                                            editState = editState.copy(clips = updated)
                                        },
                                        onApplyToAll = { transition, duration ->
                                            val updated = editState.clips.map { it.copy(transition = transition, transitionDurationMs = duration) }
                                            editState = editState.copy(clips = updated)
                                            vibrateFeedback()
                                            Toast.makeText(context, "Transition applied to all clips!", Toast.LENGTH_SHORT).show()
                                        },
                                        onPreviewTransition = { clip ->
                                            val idx = editState.clips.indexOfFirst { it.id == clip.id }
                                            if (idx >= 0) {
                                                val seekPos = (clip.effectiveDurationMs - clip.transitionDurationMs - 1200L).coerceAtLeast(0L)
                                                refreshPlayerClips(editState.clips, seekToClipIndex = idx, seekToMs = seekPos)
                                                exoPlayer.play()
                                                isPlaying = true
                                            }
                                        }
                                    )
                                }
                                EditorTab.VFX -> {
                                    VfxToolContent(
                                        currentVfx = editState.vfx,
                                        onSelectVfx = { vfx ->
                                            editState = editState.copy(vfx = vfx)
                                            vibrateFeedback()
                                        }
                                    )
                                }
                                EditorTab.GRAPHICS -> {
                                    GraphicsToolContent(
                                        currentGraphic = editState.graphicItem,
                                        onSetGraphic = { item -> editState = editState.copy(graphicItem = item) },
                                        onDeleteGraphic = {
                                            editState = editState.copy(graphicItem = null)
                                            Toast.makeText(context, "Graphic sticker removed", Toast.LENGTH_SHORT).show()
                                        },
                                        onScaleChange = { newScale ->
                                            editState.graphicItem?.let { current ->
                                                editState = editState.copy(graphicItem = current.copy(scale = newScale))
                                            }
                                        },
                                        onRotationChange = { newRot ->
                                            editState.graphicItem?.let { current ->
                                                editState = editState.copy(graphicItem = current.copy(rotationDeg = newRot))
                                            }
                                        },
                                        onOpacityChange = { newOp ->
                                            editState.graphicItem?.let { current ->
                                                editState = editState.copy(graphicItem = current.copy(opacity = newOp))
                                            }
                                        },
                                        onPositionChange = { newPos ->
                                            editState.graphicItem?.let { current ->
                                                editState = editState.copy(graphicItem = current.copy(position = newPos))
                                            }
                                        }
                                    )
                                }
                                EditorTab.VOICEOVER -> {
                                    VoiceoverToolContent(
                                        isRecording = isRecordingVoiceover,
                                        hasPermission = hasMicPermission,
                                        onRequestPermission = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                                        timerSeconds = recordingTimerSeconds,
                                        hasExistingVoiceover = editState.voiceoverUri != null,
                                        voiceoverVolume = editState.voiceoverVolume,
                                        onVolumeChange = { vol ->
                                            editState = editState.copy(voiceoverVolume = vol)
                                            extraAudioPlayer.volume = vol
                                        },
                                        onStartRecording = {
                                            if (!hasMicPermission) {
                                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                            } else {
                                                val ok = audioRecorder.startRecording()
                                                if (ok) {
                                                    exoPlayer.play()
                                                    isPlaying = true
                                                    vibrateFeedback()
                                                }
                                            }
                                        },
                                        onStopRecording = {
                                            exoPlayer.pause()
                                            isPlaying = false
                                            val uri = audioRecorder.stopRecording()
                                            if (uri != null) {
                                                editState = editState.copy(voiceoverUri = uri)
                                                Toast.makeText(context, "Voiceover recorded successfully! 🎙️", Toast.LENGTH_SHORT).show()
                                                vibrateFeedback()
                                            } else {
                                                Toast.makeText(context, "Recording failed", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        onDeleteVoiceover = {
                                            editState = editState.copy(voiceoverUri = null)
                                            extraAudioPlayer.clearMediaItems()
                                            Toast.makeText(context, "Voiceover removed", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                                EditorTab.AUDIO -> {
                                    AudioToolContent(
                                        isMuted = editState.isMuted,
                                        musicName = editState.musicName,
                                        musicVolume = editState.musicVolume,
                                        onToggleMute = { editState = editState.copy(isMuted = !editState.isMuted) },
                                        onPickMusic = { audioPickerLauncher.launch("audio/*") },
                                        onRemoveMusic = {
                                            editState = editState.copy(musicUri = null, musicName = null)
                                            extraAudioPlayer.clearMediaItems()
                                        },
                                        onVolumeChange = { vol ->
                                            editState = editState.copy(musicVolume = vol)
                                            extraAudioPlayer.volume = vol
                                        }
                                    )
                                }
                                EditorTab.TEXT -> {
                                    TextToolContent(
                                        currentText = editState.customText,
                                        currentColor = editState.textColor,
                                        currentPosition = editState.textPosition,
                                        currentScale = editState.textScale,
                                        currentAnimation = editState.textAnimation,
                                        currentFont = editState.textFont,
                                        hasBackground = editState.textBackground,
                                        onTextChange = { editState = editState.copy(customText = it) },
                                        onColorChange = { editState = editState.copy(textColor = it) },
                                        onPositionChange = { editState = editState.copy(textPosition = it) },
                                        onScaleChange = { editState = editState.copy(textScale = it) },
                                        onAnimationChange = { editState = editState.copy(textAnimation = it) },
                                        onFontChange = { editState = editState.copy(textFont = it) },
                                        onToggleBackground = { editState = editState.copy(textBackground = !editState.textBackground) },
                                        onDeleteText = {
                                            editState = editState.copy(customText = "")
                                            Toast.makeText(context, "Text cleared", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                                EditorTab.FILTERS -> {
                                    FiltersToolContent(
                                        currentFilter = editState.filter,
                                        onSelectFilter = { filter ->
                                            editState = editState.copy(filter = filter)
                                        }
                                    )
                                }
                                EditorTab.SPEED -> {
                                    SpeedToolContent(
                                        currentSpeed = editState.playbackSpeed,
                                        onSelectSpeed = { speed ->
                                            editState = editState.copy(playbackSpeed = speed)
                                        }
                                    )
                                }
                                EditorTab.RATIO -> {
                                    RatioToolContent(
                                        currentRatio = editState.aspectRatio,
                                        currentScale = editState.videoScale,
                                        onSelectRatio = { ratio -> editState = editState.copy(aspectRatio = ratio) },
                                        onScaleChange = { scale -> editState = editState.copy(videoScale = scale, isCropped = scale > 1.0f) }
                                    )
                                }
                                else -> {}
                            }
                        }
                    }
                }

                // ==================== 4. BOTTOM TOOLS NAVIGATION BAR ====================
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EditorNavTab(
                        icon = Icons.Default.ContentCut,
                        label = "Split",
                        isActive = false,
                        onClick = { performSplit() }
                    )
                    EditorNavTab(
                        icon = Icons.Default.Timeline,
                        label = "Trim",
                        isActive = activeTab == EditorTab.TRIM,
                        onClick = { activeTab = if (activeTab == EditorTab.TRIM) EditorTab.NONE else EditorTab.TRIM }
                    )
                    EditorNavTab(
                        icon = Icons.Default.Shuffle,
                        label = "Transition",
                        isActive = activeTab == EditorTab.TRANSITION || editState.clips.any { it.transition != ClipTransition.NONE },
                        badge = if (editState.clips.any { it.transition != ClipTransition.NONE }) "ON" else null,
                        onClick = { activeTab = if (activeTab == EditorTab.TRANSITION) EditorTab.NONE else EditorTab.TRANSITION }
                    )
                    EditorNavTab(
                        icon = Icons.Default.AutoFixHigh,
                        label = "VFX",
                        isActive = activeTab == EditorTab.VFX || editState.vfx != VideoVfx.NONE,
                        badge = if (editState.vfx != VideoVfx.NONE) editState.vfx.iconEmoji else null,
                        onClick = { activeTab = if (activeTab == EditorTab.VFX) EditorTab.NONE else EditorTab.VFX }
                    )
                    EditorNavTab(
                        icon = Icons.Default.AutoAwesome,
                        label = "Graphics",
                        isActive = activeTab == EditorTab.GRAPHICS || editState.graphicItem != null,
                        badge = if (editState.graphicItem != null) "ON" else null,
                        onClick = { activeTab = if (activeTab == EditorTab.GRAPHICS) EditorTab.NONE else EditorTab.GRAPHICS }
                    )
                    EditorNavTab(
                        icon = Icons.Default.Title,
                        label = "Text Anim",
                        isActive = activeTab == EditorTab.TEXT || editState.customText.isNotBlank(),
                        badge = if (editState.textAnimation != TextAnimation.NONE) editState.textAnimation.iconEmoji else if (editState.customText.isNotBlank()) "ON" else null,
                        onClick = { activeTab = if (activeTab == EditorTab.TEXT) EditorTab.NONE else EditorTab.TEXT }
                    )
                    EditorNavTab(
                        icon = Icons.Default.Mic,
                        label = "Voiceover",
                        isActive = activeTab == EditorTab.VOICEOVER || editState.voiceoverUri != null,
                        badge = if (editState.voiceoverUri != null) "ON" else null,
                        onClick = { activeTab = if (activeTab == EditorTab.VOICEOVER) EditorTab.NONE else EditorTab.VOICEOVER }
                    )
                    EditorNavTab(
                        icon = Icons.Default.MusicNote,
                        label = "Audio",
                        isActive = activeTab == EditorTab.AUDIO || editState.musicUri != null || editState.isMuted,
                        onClick = { activeTab = if (activeTab == EditorTab.AUDIO) EditorTab.NONE else EditorTab.AUDIO }
                    )
                    EditorNavTab(
                        icon = Icons.Default.AspectRatio,
                        label = "Ratio/Scale",
                        isActive = activeTab == EditorTab.RATIO || editState.aspectRatio != VideoAspectRatio.ORIGINAL,
                        badge = if (editState.aspectRatio != VideoAspectRatio.ORIGINAL) editState.aspectRatio.title else null,
                        onClick = { activeTab = if (activeTab == EditorTab.RATIO) EditorTab.NONE else EditorTab.RATIO }
                    )
                    EditorNavTab(
                        icon = Icons.Default.FilterBAndW,
                        label = "Filters",
                        isActive = activeTab == EditorTab.FILTERS || editState.filter != EditorFilter.NONE,
                        badge = if (editState.filter != EditorFilter.NONE) editState.filter.title else null,
                        onClick = { activeTab = if (activeTab == EditorTab.FILTERS) EditorTab.NONE else EditorTab.FILTERS }
                    )
                    EditorNavTab(
                        icon = Icons.Default.Speed,
                        label = "${editState.playbackSpeed}x Speed",
                        isActive = activeTab == EditorTab.SPEED || editState.playbackSpeed != 1.0f,
                        onClick = { activeTab = if (activeTab == EditorTab.SPEED) EditorTab.NONE else EditorTab.SPEED }
                    )
                }
            }

            // ==================== EXPORT SETTINGS MODAL ====================
            if (showExportDialog) {
                AlertDialog(
                    onDismissRequest = { showExportDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Hd, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export & Download HD MP4", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        }
                    },
                    text = {
                        Column {
                            Text("Select Video Resolution:", color = Color.LightGray, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(10.dp))

                            ExportQuality.values().forEach { quality ->
                                val isSelected = editState.exportQuality == quality
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) PrimaryBlue.copy(alpha = 0.2f) else Color(0xFF262626),
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) PrimaryBlue else Color.DarkGray
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable {
                                            editState = editState.copy(exportQuality = quality)
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(quality.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                            Text(quality.subtitle, color = Color.Gray, fontSize = 11.sp)
                                        }
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { editState = editState.copy(exportQuality = quality) },
                                            colors = RadioButtonDefaults.colors(selectedColor = PrimaryBlue)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = Color(0xFF1E293B),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Video saves directly to Gallery: Movies/NovaEdit", color = Color.LightGray, fontSize = 11.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showExportDialog = false
                                videoExporter.exportVideo(editState)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Start Download")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showExportDialog = false }) {
                            Text("Cancel", color = Color.Gray)
                        }
                    },
                    containerColor = Color(0xFF1E293B)
                )
            }

            // ==================== 5. EXPORTING PROGRESS OVERLAY ====================
            if (exportState is VideoExporter.ExportState.Exporting) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.88f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                progress = { (exportProgress / 100f).coerceIn(0f, 1f) },
                                color = PrimaryBlue,
                                strokeWidth = 5.dp,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Downloading & Exporting ($exportProgress%)",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Rendering HD video frames & saving directly to phone storage...",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            LinearProgressIndicator(
                                progress = { (exportProgress / 100f).coerceIn(0f, 1f) },
                                color = PrimaryBlue,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            OutlinedButton(
                                onClick = { videoExporter.cancelExport() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                            ) {
                                Text("Cancel")
                            }
                        }
                    }
                }
            }

            // ==================== 6. EXPORT SUCCESS DIALOG ====================
            if (exportState is VideoExporter.ExportState.Success) {
                val success = exportState as VideoExporter.ExportState.Success
                AlertDialog(
                    onDismissRequest = { videoExporter.cancelExport() },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(26.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Video Exported & Saved! 🎉", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        }
                    },
                    text = {
                        Column {
                            Text(
                                "Your HD MP4 video is ready and saved directly to your phone storage:",
                                color = Color.LightGray,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = Color(0xFF0F172A),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        "📁 Movies/NovaEdit/${success.displayName}",
                                        color = PrimaryBlue,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Status: Saved to Device Gallery",
                                        color = Color(0xFF4CAF50),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Direct Save / Download Confirmation
                            Button(
                                onClick = {
                                    val uri = VideoExporter.saveVideoToGallery(context, success.file, success.displayName)
                                    if (uri != null) {
                                        Toast.makeText(context, "✅ MP4 saved to Gallery (Movies/NovaEdit)!", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "Saved at: ${success.outputPath}", Toast.LENGTH_LONG).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                            ) {
                                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Download / Save", fontSize = 12.sp)
                            }

                            // Share Video
                            Button(
                                onClick = {
                                    try {
                                        val contentUri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.provider",
                                            success.file
                                        )
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "video/mp4"
                                            putExtra(Intent.EXTRA_STREAM, contentUri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Share Video"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Share: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", fontSize = 12.sp)
                            }
                        }
                    },
                    dismissButton = {
                        Row {
                            TextButton(
                                onClick = {
                                    try {
                                        val contentUri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.provider",
                                            success.file
                                        )
                                        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(contentUri, "video/mp4")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(viewIntent)
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "Video saved: ${success.outputPath}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Text("Play", color = Color.White)
                            }
                            TextButton(onClick = { videoExporter.cancelExport() }) {
                                Text("Done", color = Color.Gray)
                            }
                        }
                    },
                    containerColor = Color(0xFF1E293B)
                )
            }
        }
    }
}

// ==================== SUB-TOOL COMPOSABLES ====================

@Composable
fun TrimToolContent(
    clips: List<VideoClip>,
    selectedClipId: String?,
    currentPlayheadMs: Long,
    onUpdateClip: (VideoClip) -> Unit
) {
    val clip = clips.find { it.id == selectedClipId } ?: clips.firstOrNull()

    if (clip == null) {
        Text("Select a clip to trim", color = Color.Gray, fontSize = 12.sp)
        return
    }

    val clipDuration = if (clip.durationMs > 0) clip.durationMs else 10000L
    val startMs = clip.startMs
    val endMs = if (clip.endMs > 0) clip.endMs else clipDuration

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Trim: ${formatTimeMs(startMs)} ➔ ${formatTimeMs(endMs)}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("Length: ${formatTimeMs(endMs - startMs)}", color = PrimaryBlue, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Quick Cut at Playhead buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val newStart = currentPlayheadMs.coerceIn(0L, endMs - 500)
                    onUpdateClip(clip.copy(startMs = newStart))
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Text("[ Cut Before", fontSize = 11.sp, color = Color.White)
            }

            Button(
                onClick = {
                    val newEnd = currentPlayheadMs.coerceIn(startMs + 500, clipDuration)
                    onUpdateClip(clip.copy(endMs = newEnd))
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Text("Cut After ]", fontSize = 11.sp, color = Color.White)
            }

            IconButton(
                onClick = {
                    onUpdateClip(clip.copy(startMs = 0L, endMs = clip.durationMs))
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Default.Restore, contentDescription = "Reset Trim", tint = Color.LightGray, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun TransitionToolContent(
    clips: List<VideoClip>,
    selectedClipId: String?,
    onUpdateClip: (VideoClip) -> Unit,
    onApplyToAll: (ClipTransition, Long) -> Unit,
    onPreviewTransition: (VideoClip) -> Unit
) {
    val clip = clips.find { it.id == selectedClipId } ?: clips.firstOrNull()

    if (clip == null) {
        Text("Add clips to configure transitions between them", color = Color.Gray, fontSize = 12.sp)
        return
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Transition for: ${clip.title}",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Button(
                onClick = { onPreviewTransition(clip) },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("Preview", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Transition presets horizontal scroll
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ClipTransition.values().forEach { trans ->
                val isSelected = clip.transition == trans
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        onUpdateClip(clip.copy(transition = trans))
                    },
                    label = {
                        Text("${trans.iconEmoji} ${trans.title} (${trans.tamilName})", fontSize = 11.sp)
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Transition duration slider & Apply to all
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Duration: ${clip.transitionDurationMs}ms",
                color = Color.LightGray,
                fontSize = 11.sp,
                modifier = Modifier.width(100.dp)
            )

            Slider(
                value = clip.transitionDurationMs.toFloat(),
                onValueChange = { newDuration ->
                    onUpdateClip(clip.copy(transitionDurationMs = newDuration.toLong()))
                },
                valueRange = 300f..2000f,
                colors = SliderDefaults.colors(
                    thumbColor = PrimaryBlue,
                    activeTrackColor = PrimaryBlue
                ),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            OutlinedButton(
                onClick = { onApplyToAll(clip.transition, clip.transitionDurationMs) },
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue),
                modifier = Modifier.height(28.dp)
            ) {
                Text("All Clips", fontSize = 10.sp, color = PrimaryBlue)
            }
        }
    }
}

@Composable
fun VfxToolContent(
    currentVfx: VideoVfx,
    onSelectVfx: (VideoVfx) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            "Live VFX Effects (விஎஃப்எக்ஸ் விளைவுகள்):",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VideoVfx.values().forEach { vfx ->
                val isSelected = currentVfx == vfx
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectVfx(vfx) },
                    label = {
                        Text("${vfx.iconEmoji} ${vfx.title} (${vfx.tamilName})", fontSize = 11.sp)
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            when (currentVfx) {
                VideoVfx.GLITCH -> "⚡ Cyber Glitch: Horizontal glitch scanline bars with cyan & magenta RGB shift"
                VideoVfx.VHS_RETRO -> "📼 VHS 90s Tape: CRT tracking scanlines + retro timestamp overlay"
                VideoVfx.FILM_GRAIN -> "🎞️ Cinema Film: Classic warm vintage cinema grain & border vignette"
                VideoVfx.RGB_SPLIT -> "🌈 RGB 3D Split: Stereoscopic 3D chromatic aberration displacement"
                VideoVfx.NEON_GLOW -> "✨ Neon Glow: Luminous colorful pulsing neon aura border"
                VideoVfx.VIGNETTE -> "🎬 Cinema Vignette: Widescreen letterbox cinema bars & dark edge gradient"
                VideoVfx.FLASH -> "💥 Party Flash: Dynamic rhythmic white strobe flashes during playback"
                VideoVfx.SPARKLE -> "💖 Sparkles: Magical sparkling animated stars overlay"
                else -> "Select a VFX style above to apply live over your video clips"
            },
            color = Color.Gray,
            fontSize = 10.sp
        )
    }
}

@Composable
fun GraphicsToolContent(
    currentGraphic: GraphicOverlayItem?,
    onSetGraphic: (GraphicOverlayItem) -> Unit,
    onDeleteGraphic: () -> Unit,
    onScaleChange: (Float) -> Unit,
    onRotationChange: (Float) -> Unit,
    onOpacityChange: (Float) -> Unit,
    onPositionChange: (String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("BADGE") }

    val badges = listOf(
        "SUBSCRIBE", "LIKE & SHARE", "TRENDING 🔥",
        "VLOG 🎬", "100% REAL", "NEW ✨", "FOLLOW ME", "VIP 👑"
    )
    val emojis = listOf(
        "🔥 Fire", "🚀 Rocket", "⭐ Star", "❤️ Heart",
        "🎬 Vlog", "💯 100", "💥 Boom", "👑 King", "🎉 Party", "✨ Sparkle"
    )
    val lowerThirds = listOf(
        "LIVE NEWS", "SPECIAL GUEST", "DIRECTOR CUT", "CHAPTER 1", "TOP STORY"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Graphics & Overlays (கிராபிக்ஸ் / பேட்ஜ்):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text("வீடியோவின் மேல் பேட்ஜ், சப்ஸ்கிரைப் பட்டன், எமோஜிகள் சேர்க்கலாம்", color = Color.Gray, fontSize = 10.sp)
            }
            if (currentGraphic != null) {
                TextButton(
                    onClick = onDeleteGraphic,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("Delete", color = Color(0xFFFF5252), fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Category switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("BADGE" to "🏷️ Badges", "EMOJI" to "😄 Emojis", "LOWER_THIRD" to "📺 TV Banner").forEach { (catKey, catLabel) ->
                FilterChip(
                    selected = selectedCategory == catKey,
                    onClick = { selectedCategory = catKey },
                    label = { Text(catLabel, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Items selector horizontal strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val list = when (selectedCategory) {
                "BADGE" -> badges
                "LOWER_THIRD" -> lowerThirds
                else -> emojis
            }

            list.forEach { itemText ->
                val displayLabel = if (selectedCategory == "EMOJI") itemText.split(" ").first() else itemText
                val isSelected = currentGraphic?.textOrEmoji == displayLabel

                FilterChip(
                    selected = isSelected,
                    onClick = {
                        val currentScale = currentGraphic?.scale ?: 1.0f
                        val currentPos = currentGraphic?.position ?: "TOP_RIGHT"
                        val currentRot = currentGraphic?.rotationDeg ?: 0f
                        val currentOp = currentGraphic?.opacity ?: 1.0f
                        onSetGraphic(
                            GraphicOverlayItem(
                                textOrEmoji = displayLabel,
                                scale = currentScale,
                                position = currentPos,
                                category = selectedCategory,
                                rotationDeg = currentRot,
                                opacity = currentOp
                            )
                        )
                    },
                    label = { Text(itemText, fontSize = 11.sp) }
                )
            }
        }

        // Scale, Rotation & Position Controls if a graphic is selected
        if (currentGraphic != null) {
            Spacer(modifier = Modifier.height(6.dp))

            // Scale & Opacity Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Scale: ${(currentGraphic.scale * 100).toInt()}%",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    modifier = Modifier.width(76.dp)
                )

                Slider(
                    value = currentGraphic.scale,
                    onValueChange = onScaleChange,
                    valueRange = 0.5f..2.5f,
                    colors = SliderDefaults.colors(thumbColor = PrimaryBlue, activeTrackColor = PrimaryBlue),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    "Opacity: ${(currentGraphic.opacity * 100).toInt()}%",
                    color = Color.LightGray,
                    fontSize = 11.sp,
                    modifier = Modifier.width(78.dp)
                )

                Slider(
                    value = currentGraphic.opacity,
                    onValueChange = onOpacityChange,
                    valueRange = 0.2f..1.0f,
                    colors = SliderDefaults.colors(thumbColor = PrimaryBlue, activeTrackColor = PrimaryBlue),
                    modifier = Modifier.weight(1f)
                )
            }

            // Position selector chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Position:", color = Color.Gray, fontSize = 11.sp)
                listOf(
                    "TOP_LEFT" to "Top L",
                    "TOP_RIGHT" to "Top R",
                    "TOP_CENTER" to "Top C",
                    "CENTER" to "Center",
                    "BOTTOM_LEFT" to "Bot L",
                    "BOTTOM_RIGHT" to "Bot R"
                ).forEach { (posKey, posLabel) ->
                    FilterChip(
                        selected = currentGraphic.position == posKey,
                        onClick = { onPositionChange(posKey) },
                        label = { Text(posLabel, fontSize = 10.sp) }
                    )
                }
            }
        }
    }
}

@Composable
fun VoiceoverToolContent(
    isRecording: Boolean,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    timerSeconds: Int,
    hasExistingVoiceover: Boolean,
    voiceoverVolume: Float,
    onVolumeChange: (Float) -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onDeleteVoiceover: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (!hasPermission) {
            Text("Microphone permission required to record your voice", color = Color.LightGray, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Grant Mic Permission")
            }
        } else {
            // Big Record Button with Pulse Animation
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val scale by infiniteTransition.animateFloat(
                initialValue = 1f,
                targetValue = if (isRecording) 1.2f else 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale"
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                IconButton(
                    onClick = {
                        if (isRecording) {
                            onStopRecording()
                        } else {
                            onStartRecording()
                        }
                    },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(if (isRecording) Color.Red else PrimaryBlue)
                ) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Record Voiceover",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Column {
                    Text(
                        if (isRecording) "🔴 Recording... Speak now!" else if (hasExistingVoiceover) "Voiceover Active! Tap to Re-record" else "Tap Mic to Record Narration",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        if (isRecording) "Timer: ${formatSeconds(timerSeconds)} (Sync with video)" else "Audio records synchronously with video clips",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            if (hasExistingVoiceover) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Volume", color = Color.LightGray, fontSize = 11.sp)
                    }

                    Slider(
                        value = voiceoverVolume,
                        onValueChange = onVolumeChange,
                        valueRange = 0f..1f,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 8.dp)
                    )

                    IconButton(
                        onClick = onDeleteVoiceover,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AudioToolContent(
    isMuted: Boolean,
    musicName: String?,
    musicVolume: Float,
    onToggleMute: () -> Unit,
    onPickMusic: () -> Unit,
    onRemoveMusic: () -> Unit,
    onVolumeChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (isMuted) Icons.Default.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = null,
                    tint = if (isMuted) Color(0xFFFF5252) else PrimaryBlue
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Original Video Sound", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (isMuted) "Muted (Silent)" else "Enabled", color = Color.Gray, fontSize = 10.sp)
                }
            }

            Switch(
                checked = !isMuted,
                onCheckedChange = { onToggleMute() },
                colors = SwitchDefaults.colors(checkedThumbColor = PrimaryBlue)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Background Music Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Background Music", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(musicName ?: "None selected", color = if (musicName != null) PrimaryBlue else Color.Gray, fontSize = 10.sp)
            }

            Row {
                Button(
                    onClick = onPickMusic,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (musicName != null) "Change" else "Add Music", fontSize = 11.sp)
                }

                if (musicName != null) {
                    IconButton(onClick = onRemoveMusic) {
                        Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.Red, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        if (musicName != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Music Vol", color = Color.Gray, fontSize = 11.sp)
                Slider(
                    value = musicVolume,
                    onValueChange = onVolumeChange,
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun TextToolContent(
    currentText: String,
    currentColor: Int,
    currentPosition: String,
    currentScale: Float,
    currentAnimation: TextAnimation,
    currentFont: TextFont,
    hasBackground: Boolean,
    onTextChange: (String) -> Unit,
    onColorChange: (Int) -> Unit,
    onPositionChange: (String) -> Unit,
    onScaleChange: (Float) -> Unit,
    onAnimationChange: (TextAnimation) -> Unit,
    onFontChange: (TextFont) -> Unit,
    onToggleBackground: () -> Unit,
    onDeleteText: () -> Unit
) {
    val colors = listOf(
        AndroidColor.WHITE to "White",
        AndroidColor.YELLOW to "Yellow",
        AndroidColor.CYAN to "Cyan",
        AndroidColor.RED to "Red",
        AndroidColor.GREEN to "Green",
        AndroidColor.MAGENTA to "Pink"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Overlay Text & Caption (டெக்ஸ்ட் அனிமேஷன்):", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (currentText.isNotBlank()) {
                TextButton(
                    onClick = onDeleteText,
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(2.dp))
                    Text("Clear Text", color = Color(0xFFFF5252), fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        OutlinedTextField(
            value = currentText,
            onValueChange = onTextChange,
            placeholder = { Text("Enter caption, title, or watermark...", color = Color.Gray, fontSize = 12.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = PrimaryBlue,
                unfocusedBorderColor = Color.DarkGray
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Text Animation selector
        Text("Text Animation (அனிமேஷன் தேர்வு):", color = Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextAnimation.values().forEach { anim ->
                FilterChip(
                    selected = currentAnimation == anim,
                    onClick = { onAnimationChange(anim) },
                    label = { Text("${anim.iconEmoji} ${anim.title} (${anim.tamilName})", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Font Style selector
        Text("Font Style (எழுத்துரு):", color = Color.LightGray, fontSize = 11.sp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextFont.values().forEach { font ->
                FilterChip(
                    selected = currentFont == font,
                    onClick = { onFontChange(font) },
                    label = { Text(font.title, fontSize = 10.sp) }
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Pill Background Toggle
            FilterChip(
                selected = hasBackground,
                onClick = onToggleBackground,
                label = { Text(if (hasBackground) "🔲 Background ON" else "🔳 Background OFF", fontSize = 10.sp) }
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Text Scale slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Text Size: ${(currentScale * 100).toInt()}%",
                color = Color.LightGray,
                fontSize = 11.sp,
                modifier = Modifier.width(90.dp)
            )
            Slider(
                value = currentScale,
                onValueChange = onScaleChange,
                valueRange = 0.7f..2.2f,
                colors = SliderDefaults.colors(
                    thumbColor = PrimaryBlue,
                    activeTrackColor = PrimaryBlue
                ),
                modifier = Modifier.weight(1f)
            )
        }

        // Color and Position chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Color:", color = Color.LightGray, fontSize = 11.sp)
            colors.forEach { (colorVal, _) ->
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(Color(colorVal))
                        .border(
                            width = if (currentColor == colorVal) 2.dp else 0.dp,
                            color = if (currentColor == colorVal) Color.White else Color.Transparent,
                            shape = CircleShape
                        )
                        .clickable { onColorChange(colorVal) }
                )
            }

            Spacer(modifier = Modifier.width(6.dp))
            Text("Position:", color = Color.LightGray, fontSize = 11.sp)
            listOf("TOP", "CENTER", "BOTTOM").forEach { pos ->
                FilterChip(
                    selected = currentPosition == pos,
                    onClick = { onPositionChange(pos) },
                    label = { Text(pos, fontSize = 9.sp) }
                )
            }
        }
    }
}

@Composable
fun RatioToolContent(
    currentRatio: VideoAspectRatio,
    currentScale: Float,
    onSelectRatio: (VideoAspectRatio) -> Unit,
    onScaleChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Aspect Ratio / Canvas Format:", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VideoAspectRatio.values().forEach { ratio ->
                FilterChip(
                    selected = currentRatio == ratio,
                    onClick = { onSelectRatio(ratio) },
                    label = { Text("${ratio.title} (${ratio.desc})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PrimaryBlue,
                        selectedLabelColor = Color.Black
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Video Zoom & Crop Scale Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Zoom: ${(currentScale * 100).toInt()}%",
                color = Color.LightGray,
                fontSize = 11.sp,
                modifier = Modifier.width(80.dp)
            )

            Slider(
                value = currentScale,
                onValueChange = onScaleChange,
                valueRange = 1.0f..1.6f,
                colors = SliderDefaults.colors(
                    thumbColor = PrimaryBlue,
                    activeTrackColor = PrimaryBlue
                ),
                modifier = Modifier.weight(1f)
            )

            if (currentScale > 1.0f) {
                IconButton(
                    onClick = { onScaleChange(1.0f) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Restore, contentDescription = "Reset Zoom", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun FiltersToolContent(
    currentFilter: EditorFilter,
    onSelectFilter: (EditorFilter) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        EditorFilter.values().forEach { filter ->
            FilterChip(
                selected = currentFilter == filter,
                onClick = { onSelectFilter(filter) },
                label = { Text(filter.title, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryBlue,
                    selectedLabelColor = Color.Black
                )
            )
        }
    }
}

@Composable
fun SpeedToolContent(
    currentSpeed: Float,
    onSelectSpeed: (Float) -> Unit
) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        speeds.forEach { speed ->
            FilterChip(
                selected = currentSpeed == speed,
                onClick = { onSelectSpeed(speed) },
                label = { Text("${speed}x", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PrimaryBlue,
                    selectedLabelColor = Color.Black
                )
            )
        }
    }
}

@Composable
fun EditorNavTab(
    icon: ImageVector,
    label: String,
    isActive: Boolean = false,
    badge: String? = null,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (isActive) PrimaryBlue else Color.White,
                modifier = Modifier.size(24.dp)
            )
            if (badge != null) {
                Box(
                    modifier = Modifier
                        .offset(x = 6.dp, y = (-4).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(PrimaryBlue)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(badge, color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            label,
            color = if (isActive) PrimaryBlue else Color.LightGray,
            fontSize = 10.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// Helpers
fun formatTimeMs(timeMs: Long): String {
    val totalSeconds = (timeMs / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val millisTenths = (timeMs % 1000) / 100
    return String.format(java.util.Locale.US, "%02d:%02d.%d", minutes, seconds, millisTenths)
}

fun formatSeconds(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format(java.util.Locale.US, "%02d:%02d", m, s)
}
