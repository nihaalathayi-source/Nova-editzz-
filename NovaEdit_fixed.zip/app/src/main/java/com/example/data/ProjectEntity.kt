package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val timestamp: Long = System.currentTimeMillis(),
    val projectType: String, // "VIDEO", "PHOTO", "COLLAGE"
    val mediaUris: String, // Comma separated URIs for now, as a simplified mock
    val thumbnailUri: String? = null,
    val lastModified: Long = System.currentTimeMillis()
)
