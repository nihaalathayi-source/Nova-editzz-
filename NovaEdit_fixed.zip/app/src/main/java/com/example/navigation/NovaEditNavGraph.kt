package com.example.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.CollageScreen

@Composable
fun NovaEditNavGraph() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onNavigateToVideoEditor = { navController.navigate("video_editor") },
                onNavigateToPhotoEditor = { navController.navigate("photo_editor") },
                onNavigateToCollage = { navController.navigate("collage") }
            )
        }
        composable("video_editor") {
            VideoEditorScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable("photo_editor") {
            PhotoEditorScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable("collage") {
            CollageScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
