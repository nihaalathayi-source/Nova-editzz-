package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.AppDatabase
import com.example.data.ProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class CollagePhoto(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val scale: Float = 1.0f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val rotation: Float = 0f,
    val isFlipped: Boolean = false,
    val filter: EditorFilter = EditorFilter.NONE
)

data class CollageSticker(
    val id: String = UUID.randomUUID().toString(),
    val textOrEmoji: String,
    val scale: Float = 1.0f,
    val xPercent: Float = 0.5f,
    val yPercent: Float = 0.5f
)

enum class CollageLayoutType(val title: String, val minPhotos: Int, val maxPhotos: Int) {
    SPLIT_HORIZONTAL("2 Columns", 2, 2),
    SPLIT_VERTICAL("2 Rows", 2, 2),
    HERO_TOP_2_BOTTOM("Hero Top", 3, 3),
    HERO_BOTTOM_2_TOP("Hero Bottom", 3, 3),
    THREE_COLUMNS("3 Columns", 3, 3),
    GRID_2X2("2x2 Grid", 4, 4),
    HERO_LEFT_3_RIGHT("Hero Left", 4, 4),
    HERO_TOP_3_BOTTOM("Hero Top 4", 4, 4),
    FIVE_MOSAIC("5 Mosaic", 5, 5),
    SIX_GRID("6 Grid", 6, 6),
    FREEFORM("Scrapbook", 1, 9)
}

data class CollageStyle(
    val spacingDp: Float = 8f,
    val cornerRadiusDp: Float = 12f,
    val backgroundColor: Int = android.graphics.Color.parseColor("#181824"),
    val backgroundEndColor: Int? = android.graphics.Color.parseColor("#0C0C14"),
    val borderColor: Int = android.graphics.Color.parseColor("#7C4DFF"),
    val borderWidthDp: Float = 0f,
    val aspectRatioWidth: Int = 1,
    val aspectRatioHeight: Int = 1,
    val overlayText: String = "",
    val textColor: Int = android.graphics.Color.WHITE,
    val textSizeSp: Float = 28f
)

object CollageExporter {

    /**
     * Renders the collage into a high-resolution Bitmap on a background thread.
     */
    suspend fun renderCollageToBitmap(
        context: Context,
        photos: List<CollagePhoto>,
        layoutType: CollageLayoutType,
        style: CollageStyle,
        stickers: List<CollageSticker>,
        outputWidth: Int = 1080
    ): Bitmap = withContext(Dispatchers.IO) {
        val outputHeight = (outputWidth * style.aspectRatioHeight) / style.aspectRatioWidth
        val bitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // 1. Draw Background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        if (style.backgroundEndColor != null) {
            bgPaint.shader = LinearGradient(
                0f, 0f, 0f, outputHeight.toFloat(),
                style.backgroundColor, style.backgroundEndColor,
                Shader.TileMode.CLAMP
            )
        } else {
            bgPaint.color = style.backgroundColor
        }
        canvas.drawRect(0f, 0f, outputWidth.toFloat(), outputHeight.toFloat(), bgPaint)

        // Calculate frame rectangles based on layout
        val padding = style.spacingDp * (outputWidth / 360f)
        val cornerRadius = style.cornerRadiusDp * (outputWidth / 360f)
        val photoRects = calculateLayoutRects(
            layoutType = layoutType,
            photoCount = photos.size,
            width = outputWidth.toFloat(),
            height = outputHeight.toFloat(),
            padding = padding
        )

        // 2. Draw each photo in its designated rectangle
        for (i in photos.indices) {
            val photo = photos[i]
            val rect = photoRects.getOrNull(i) ?: continue

            val srcBitmap = loadBitmapFromUri(context, photo.uri, rect.width().toInt(), rect.height().toInt())
            if (srcBitmap != null) {
                drawPhotoInRect(
                    canvas = canvas,
                    bitmap = srcBitmap,
                    rect = rect,
                    cornerRadius = cornerRadius,
                    photo = photo
                )
            }
        }

        // 3. Draw outer border if enabled
        if (style.borderWidthDp > 0) {
            val strokeWidth = style.borderWidthDp * (outputWidth / 360f)
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = style.borderColor
                this.style = Paint.Style.STROKE
                this.strokeWidth = strokeWidth
            }
            canvas.drawRect(
                strokeWidth / 2f,
                strokeWidth / 2f,
                outputWidth - strokeWidth / 2f,
                outputHeight - strokeWidth / 2f,
                borderPaint
            )
        }

        // 4. Draw Overlay Text
        if (style.overlayText.isNotBlank()) {
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = style.textColor
                textSize = style.textSizeSp * (outputWidth / 360f)
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                setShadowLayer(8f, 2f, 2f, android.graphics.Color.BLACK)
            }
            val textY = outputHeight - (40f * (outputWidth / 360f))
            canvas.drawText(style.overlayText, outputWidth / 2f, textY, textPaint)
        }

        // 5. Draw Stickers / Emojis
        for (sticker in stickers) {
            val stickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 48f * sticker.scale * (outputWidth / 360f)
                textAlign = Paint.Align.CENTER
            }
            val sx = sticker.xPercent * outputWidth
            val sy = sticker.yPercent * outputHeight
            canvas.drawText(sticker.textOrEmoji, sx, sy, stickerPaint)
        }

        bitmap
    }

    private fun drawPhotoInRect(
        canvas: Canvas,
        bitmap: Bitmap,
        rect: RectF,
        cornerRadius: Float,
        photo: CollagePhoto
    ) {
        val saveCount = canvas.save()

        // Clip to rounded rect
        val path = Path()
        path.addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
        canvas.clipPath(path)

        // Draw background in cell
        val cellBg = Paint().apply { color = android.graphics.Color.parseColor("#1F1F2E") }
        canvas.drawRect(rect, cellBg)

        // Setup matrix for scale, translation, rotation, flip
        val matrix = Matrix()
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()

        // Scale to fill cell (aspect fill)
        val scaleX = rect.width() / bw
        val scaleY = rect.height() / bh
        val baseScale = maxOf(scaleX, scaleY)
        val finalScale = baseScale * photo.scale

        matrix.postTranslate(-bw / 2f, -bh / 2f)

        if (photo.isFlipped) {
            matrix.postScale(-1f, 1f)
        }
        if (photo.rotation != 0f) {
            matrix.postRotate(photo.rotation)
        }

        matrix.postScale(finalScale, finalScale)
        matrix.postTranslate(rect.centerX() + photo.offsetX, rect.centerY() + photo.offsetY)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        applyFilterToPaint(paint, photo.filter)

        canvas.drawBitmap(bitmap, matrix, paint)
        canvas.restoreToCount(saveCount)
    }

    private fun applyFilterToPaint(paint: Paint, filter: EditorFilter) {
        when (filter) {
            EditorFilter.GRAYSCALE -> {
                val matrix = ColorMatrix()
                matrix.setSaturation(0f)
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            EditorFilter.SEPIA -> {
                val matrix = ColorMatrix(floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            EditorFilter.WARM -> {
                val matrix = ColorMatrix(floatArrayOf(
                    1.2f, 0f, 0f, 0f, 0f,
                    0f, 1.05f, 0f, 0f, 0f,
                    0f, 0f, 0.85f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            EditorFilter.COOL -> {
                val matrix = ColorMatrix(floatArrayOf(
                    0.85f, 0f, 0f, 0f, 0f,
                    0f, 1.0f, 0f, 0f, 0f,
                    0f, 0f, 1.25f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                ))
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            EditorFilter.INVERT -> {
                val matrix = ColorMatrix(floatArrayOf(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                ))
                paint.colorFilter = ColorMatrixColorFilter(matrix)
            }
            else -> {}
        }
    }

    private fun calculateLayoutRects(
        layoutType: CollageLayoutType,
        photoCount: Int,
        width: Float,
        height: Float,
        padding: Float
    ): List<RectF> {
        val rects = mutableListOf<RectF>()
        val pad = padding.coerceAtLeast(0f)

        when (layoutType) {
            CollageLayoutType.SPLIT_HORIZONTAL -> {
                val w = (width - 3 * pad) / 2f
                val h = height - 2 * pad
                rects.add(RectF(pad, pad, pad + w, pad + h))
                rects.add(RectF(pad * 2 + w, pad, pad * 2 + 2 * w, pad + h))
            }
            CollageLayoutType.SPLIT_VERTICAL -> {
                val w = width - 2 * pad
                val h = (height - 3 * pad) / 2f
                rects.add(RectF(pad, pad, pad + w, pad + h))
                rects.add(RectF(pad, pad * 2 + h, pad + w, pad * 2 + 2 * h))
            }
            CollageLayoutType.HERO_TOP_2_BOTTOM -> {
                val wTop = width - 2 * pad
                val hTop = (height - 3 * pad) * 0.55f
                rects.add(RectF(pad, pad, pad + wTop, pad + hTop))

                val wBottom = (width - 3 * pad) / 2f
                val hBottom = height - 3 * pad - hTop
                val topY = pad * 2 + hTop
                rects.add(RectF(pad, topY, pad + wBottom, topY + hBottom))
                rects.add(RectF(pad * 2 + wBottom, topY, pad * 2 + 2 * wBottom, topY + hBottom))
            }
            CollageLayoutType.HERO_BOTTOM_2_TOP -> {
                val wTop = (width - 3 * pad) / 2f
                val hTop = (height - 3 * pad) * 0.45f
                rects.add(RectF(pad, pad, pad + wTop, pad + hTop))
                rects.add(RectF(pad * 2 + wTop, pad, pad * 2 + 2 * wTop, pad + hTop))

                val wBottom = width - 2 * pad
                val hBottom = height - 3 * pad - hTop
                val topY = pad * 2 + hTop
                rects.add(RectF(pad, topY, pad + wBottom, topY + hBottom))
            }
            CollageLayoutType.THREE_COLUMNS -> {
                val w = (width - 4 * pad) / 3f
                val h = height - 2 * pad
                for (i in 0 until 3) {
                    val left = pad + i * (w + pad)
                    rects.add(RectF(left, pad, left + w, pad + h))
                }
            }
            CollageLayoutType.GRID_2X2 -> {
                val w = (width - 3 * pad) / 2f
                val h = (height - 3 * pad) / 2f
                rects.add(RectF(pad, pad, pad + w, pad + h))
                rects.add(RectF(pad * 2 + w, pad, pad * 2 + 2 * w, pad + h))
                rects.add(RectF(pad, pad * 2 + h, pad + w, pad * 2 + 2 * h))
                rects.add(RectF(pad * 2 + w, pad * 2 + h, pad * 2 + 2 * w, pad * 2 + 2 * h))
            }
            CollageLayoutType.HERO_LEFT_3_RIGHT -> {
                val wLeft = (width - 3 * pad) * 0.6f
                val hLeft = height - 2 * pad
                rects.add(RectF(pad, pad, pad + wLeft, pad + hLeft))

                val wRight = width - 3 * pad - wLeft
                val hItem = (height - 4 * pad) / 3f
                val startX = pad * 2 + wLeft
                for (i in 0 until 3) {
                    val startY = pad + i * (hItem + pad)
                    rects.add(RectF(startX, startY, startX + wRight, startY + hItem))
                }
            }
            CollageLayoutType.HERO_TOP_3_BOTTOM -> {
                val wTop = width - 2 * pad
                val hTop = (height - 3 * pad) * 0.6f
                rects.add(RectF(pad, pad, pad + wTop, pad + hTop))

                val wBottom = (width - 4 * pad) / 3f
                val hBottom = height - 3 * pad - hTop
                val topY = pad * 2 + hTop
                for (i in 0 until 3) {
                    val left = pad + i * (wBottom + pad)
                    rects.add(RectF(left, topY, left + wBottom, topY + hBottom))
                }
            }
            CollageLayoutType.FIVE_MOSAIC -> {
                val wTop = (width - 3 * pad) / 2f
                val hTop = (height - 3 * pad) * 0.5f
                rects.add(RectF(pad, pad, pad + wTop, pad + hTop))
                rects.add(RectF(pad * 2 + wTop, pad, pad * 2 + 2 * wTop, pad + hTop))

                val wBottom = (width - 4 * pad) / 3f
                val hBottom = height - 3 * pad - hTop
                val topY = pad * 2 + hTop
                for (i in 0 until 3) {
                    val left = pad + i * (wBottom + pad)
                    rects.add(RectF(left, topY, left + wBottom, topY + hBottom))
                }
            }
            CollageLayoutType.SIX_GRID -> {
                val w = (width - 4 * pad) / 3f
                val h = (height - 3 * pad) / 2f
                for (row in 0 until 2) {
                    for (col in 0 until 3) {
                        val left = pad + col * (w + pad)
                        val top = pad + row * (h + pad)
                        rects.add(RectF(left, top, left + w, top + h))
                    }
                }
            }
            CollageLayoutType.FREEFORM -> {
                // Scrapbook layout with dynamic placements
                val count = photoCount.coerceIn(1, 9)
                val cardW = width * 0.48f
                val cardH = height * 0.45f
                val positions = listOf(
                    PointF(width * 0.08f, height * 0.08f),
                    PointF(width * 0.45f, height * 0.12f),
                    PointF(width * 0.12f, height * 0.48f),
                    PointF(width * 0.48f, height * 0.46f),
                    PointF(width * 0.28f, height * 0.28f)
                )
                for (i in 0 until count) {
                    val pos = positions[i % positions.size]
                    rects.add(RectF(pos.x, pos.y, pos.x + cardW, pos.y + cardH))
                }
            }
        }

        // Fill remaining if photoCount exceeds layout
        while (rects.size < photoCount) {
            rects.add(RectF(pad, pad, width - pad, height - pad))
        }

        return rects
    }

    private fun loadBitmapFromUri(context: Context, uri: Uri, targetW: Int, targetH: Int): Bitmap? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, boundsOptions)
            inputStream?.close()

            val sampleSize = calculateInSampleSize(boundsOptions, targetW.coerceAtLeast(100), targetH.coerceAtLeast(100))
            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }

            val stream2 = context.contentResolver.openInputStream(uri)
            val decoded = BitmapFactory.decodeStream(stream2, null, decodeOptions)
            stream2?.close()
            decoded
        } catch (_: Exception) {
            // Generate nice placeholder bitmap if uri cannot be opened (e.g. sample image)
            val ph = Bitmap.createBitmap(targetW.coerceAtLeast(300), targetH.coerceAtLeast(300), Bitmap.Config.ARGB_8888)
            val c = Canvas(ph)
            c.drawColor(android.graphics.Color.parseColor("#37474F"))
            val p = Paint().apply {
                color = android.graphics.Color.WHITE
                textSize = 36f
                textAlign = Paint.Align.CENTER
            }
            c.drawText("Photo", ph.width / 2f, ph.height / 2f, p)
            ph
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    /**
     * Saves the collage as a high-definition JPEG/PNG into public Gallery (Pictures/NovaEdit)
     */
    suspend fun saveCollageImageToGallery(
        context: Context,
        bitmap: Bitmap,
        title: String = "NovaEdit_Collage"
    ): Pair<File, Uri?> = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "${title}_$timeStamp.jpg"

        // Save internal file
        val outputDir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "NovaEdit")
        if (!outputDir.exists()) outputDir.mkdirs()
        val localFile = File(outputDir, fileName)

        FileOutputStream(localFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)
        }

        // Save into MediaStore.Images
        var galleryUri: Uri? = null
        try {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.TITLE, fileName.substringBeforeLast("."))
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NovaEdit")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            galleryUri = resolver.insert(collection, values)
            if (galleryUri != null) {
                resolver.openOutputStream(galleryUri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(galleryUri, values, null, null)
                }

                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(localFile.absolutePath),
                    arrayOf("image/jpeg"),
                    null
                )
            }
        } catch (_: Exception) {}

        // Save to Room DB
        try {
            val db = AppDatabase.getDatabase(context)

            db.projectDao().insertProject(
                ProjectEntity(
                    name = "Collage_${SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date())}",
                    projectType = "COLLAGE",
                    mediaUris = localFile.absolutePath,
                    thumbnailUri = localFile.absolutePath
                )
            )
        } catch (_: Exception) {}

        Pair(localFile, galleryUri)
    }

    /**
     * Exports the collage as an animated 1080p/720p HD MP4 video with smooth motion!
     * Straight MP4 output directly to Gallery without errors.
     */
    suspend fun exportCollageAsMp4Video(
        context: Context,
        bitmap: Bitmap,
        durationSeconds: Int = 4,
        onProgress: (Int) -> Unit = {}
    ): Pair<File, Uri?> = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "NovaEdit_Collage_$timeStamp.mp4"

        val outputDir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "NovaEdit")
        if (!outputDir.exists()) outputDir.mkdirs()
        val outputFile = File(outputDir, fileName)

        // Make dimensions divisible by 16 for H.264 video codec compatibility
        val rawWidth = bitmap.width.coerceAtMost(1080)
        val rawHeight = bitmap.height.coerceAtMost(1920)
        val videoWidth = (rawWidth / 16) * 16
        val videoHeight = (rawHeight / 16) * 16

        val scaledBitmap = if (bitmap.width != videoWidth || bitmap.height != videoHeight) {
            Bitmap.createScaledBitmap(bitmap, videoWidth, videoHeight, true)
        } else {
            bitmap
        }

        val frameRate = 30
        val totalFrames = durationSeconds * frameRate
        val bitRate = 4_000_000 // 4 Mbps HD

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, videoWidth, videoHeight).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = codec.createInputSurface()
        codec.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var trackIndex = -1
        var muxerStarted = false
        val bufferInfo = MediaCodec.BufferInfo()

        try {
            for (frame in 0 until totalFrames) {
                // Subtle Ken-Burns zoom effect (1.0 to 1.06)
                val zoom = 1.0f + (frame.toFloat() / totalFrames) * 0.06f
                val canvas = inputSurface.lockCanvas(null)
                canvas.drawColor(android.graphics.Color.BLACK)

                val m = Matrix()
                m.postScale(zoom, zoom, videoWidth / 2f, videoHeight / 2f)
                canvas.drawBitmap(scaledBitmap, m, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))

                inputSurface.unlockCanvasAndPost(canvas)

                // Drain output from codec
                var outIndex = codec.dequeueOutputBuffer(bufferInfo, 10000)
                while (outIndex >= 0) {
                    val encodedData = codec.getOutputBuffer(outIndex)
                    if (encodedData != null) {
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0) {
                            if (!muxerStarted) {
                                trackIndex = muxer.addTrack(codec.outputFormat)
                                muxer.start()
                                muxerStarted = true
                            }
                            bufferInfo.presentationTimeUs = (frame * 1_000_000L) / frameRate
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                        }
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    outIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
                }

                val progress = ((frame + 1) * 90) / totalFrames
                withContext(Dispatchers.Main) { onProgress(progress) }
            }

            // Signal end of stream
            codec.signalEndOfInputStream()

            var eos = false
            while (!eos) {
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10000)
                if (outIndex >= 0) {
                    val encodedData = codec.getOutputBuffer(outIndex)
                    if (encodedData != null && bufferInfo.size > 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(trackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                        eos = true
                    }
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    eos = true
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { inputSurface.release() } catch (_: Exception) {}
            try {
                if (muxerStarted) muxer.stop()
                muxer.release()
            } catch (_: Exception) {}
        }

        withContext(Dispatchers.Main) { onProgress(100) }

        // Save MP4 to MediaStore (Movies/NovaEdit)
        val galleryUri = VideoExporter.saveVideoToGallery(context, outputFile, fileName)

        // Save project into Room DB
        try {
            val db = AppDatabase.getDatabase(context)

            db.projectDao().insertProject(
                ProjectEntity(
                    name = "Collage_Video_${SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date())}",
                    projectType = "COLLAGE",
                    mediaUris = outputFile.absolutePath,
                    thumbnailUri = outputFile.absolutePath
                )
            )
        } catch (_: Exception) {}

        Pair(outputFile, galleryUri)
    }
}
