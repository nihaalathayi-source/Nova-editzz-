package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val title: String = "Clip",
    val startMs: Long = 0L,
    val endMs: Long = -1L,
    val durationMs: Long = 0L,
    val speed: Float = 1.0f,
    val transition: ClipTransition = ClipTransition.NONE,
    val transitionDurationMs: Long = 800L
) {
    val effectiveDurationMs: Long
        get() {
            val end = if (endMs > 0 && endMs <= durationMs) endMs else durationMs
            val raw = (end - startMs).coerceAtLeast(0L)
            return (raw / speed).toLong()
        }
}

enum class ClipTransition(val title: String, val tamilName: String, val iconEmoji: String) {
    NONE("None", "இல்லை", "🚫"),
    CROSSFADE("Crossfade", "கலவை", "🔀"),
    FADE_BLACK("Fade Black", "இருள் மறைவு", "⬛"),
    FADE_WHITE("Fade White", "ஒளி மறைவு", "⬜"),
    SLIDE_LEFT("Slide Left", "இடது நகர்வு", "⬅️"),
    SLIDE_RIGHT("Slide Right", "வலது நகர்வு", "➡️"),
    ZOOM_IN("Zoom In", "பெரிதாக்குதல்", "🔍"),
    WIPE("Wipe", "துடைப்பு", "🧹")
}

enum class VideoVfx(val title: String, val tamilName: String, val iconEmoji: String) {
    NONE("None", "இல்லை", "🚫"),
    GLITCH("Cyber Glitch", "சைபர் கிளிட்ச்", "⚡"),
    VHS_RETRO("VHS 90s Tape", "ரெட்ரோ விஎச்எஸ்", "📼"),
    FILM_GRAIN("Cinema Film", "சினிமா கிரைன்", "🎞️"),
    RGB_SPLIT("RGB 3D Split", "3D ஆர்ஜிபி", "🌈"),
    NEON_GLOW("Neon Glow", "நியான் ஒளி", "✨"),
    VIGNETTE("Cinema Vignette", "விக்னெட் சினிமா", "🎬"),
    FLASH("Party Flash", "பார்ட்டி ஃப்ளாஷ்", "💥"),
    SPARKLE("Sparkles", "மின்னும் துகள்கள்", "💖")
}

enum class TextAnimation(val title: String, val tamilName: String, val iconEmoji: String) {
    NONE("Static", "நிலையானது", "⏹️"),
    TYPEWRITER("Typewriter", "டைப்ரைட்டர் தட்டச்சு", "⌨️"),
    SLIDE_UP("Slide Up", "கீழிருந்து மேலே", "⬆️"),
    FADE_IN("Fade In", "மெதுவாகத் தோன்றுதல்", "🌫️"),
    BOUNCE("Bounce", "துள்ளல் அனிமேஷன்", "🏀"),
    PULSE("Pulse", "துடிப்பு அனிமேஷன்", "💓"),
    GLITCH("Glitch", "கிளிட்ச் அதிர்வு", "⚡"),
    NEON_GLOW("Neon Glow", "ஒளிரும் நியான்", "🌟")
}

enum class TextFont(val title: String) {
    DEFAULT("Modern Sans"),
    SERIF("Classic Serif"),
    MONO("Retro Monospace"),
    CURSIVE("Script Cursive"),
    BOLD_HEAVY("Impact Heavy")
}

enum class EditorFilter(val title: String) {
    NONE("Original"),
    GRAYSCALE("B&W Noir"),
    SEPIA("Vintage"),
    WARM("Golden Warm"),
    COOL("Teal Cool"),
    INVERT("Cyber Neon")
}

enum class ExportQuality(val title: String, val subtitle: String, val height: Int) {
    FULL_HD_1080P("1080p Full HD", "Crisp High Definition (Recommended)", 1080),
    HD_720P("720p HD", "Fast Standard HD MP4", 720),
    ORIGINAL("Original Quality", "Match Source Video", 0)
}

enum class VideoAspectRatio(val title: String, val ratio: Float?, val desc: String) {
    ORIGINAL("Original", null, "Source Aspect"),
    RATIO_16_9("16:9", 16f / 9f, "YouTube / TV"),
    RATIO_9_16("9:16", 9f / 16f, "Reels / Shorts / TikTok"),
    RATIO_1_1("1:1", 1f, "Square Post"),
    RATIO_4_5("4:5", 4f / 5f, "Portrait Feed")
}

data class GraphicOverlayItem(
    val id: String = UUID.randomUUID().toString(),
    val textOrEmoji: String,
    val scale: Float = 1.0f, // 0.5f to 2.5f
    val position: String = "TOP_RIGHT", // TOP_LEFT, TOP_RIGHT, CENTER, BOTTOM_LEFT, BOTTOM_RIGHT, TOP_CENTER
    val category: String = "EMOJI", // EMOJI, BADGE, LOWER_THIRD
    val opacity: Float = 1.0f,
    val rotationDeg: Float = 0f
)

data class VideoEditState(
    val clips: List<VideoClip> = emptyList(),
    val selectedClipId: String? = null,
    val isMuted: Boolean = false,
    val filter: EditorFilter = EditorFilter.NONE,
    val vfx: VideoVfx = VideoVfx.NONE,
    val isCropped: Boolean = false,
    val videoScale: Float = 1.0f,
    val aspectRatio: VideoAspectRatio = VideoAspectRatio.ORIGINAL,
    val customText: String = "",
    val textColor: Int = Color.WHITE,
    val textPosition: String = "BOTTOM", // "TOP", "CENTER", "BOTTOM"
    val textScale: Float = 1.0f,
    val textAnimation: TextAnimation = TextAnimation.NONE,
    val textFont: TextFont = TextFont.DEFAULT,
    val textBackground: Boolean = true,
    val graphicItem: GraphicOverlayItem? = null,
    val playbackSpeed: Float = 1.0f,
    val exportQuality: ExportQuality = ExportQuality.FULL_HD_1080P,
    val voiceoverUri: Uri? = null,
    val voiceoverVolume: Float = 1.0f,
    val musicUri: Uri? = null,
    val musicName: String? = null,
    val musicVolume: Float = 0.8f
)

/**
 * Fades a clip's brightness down to black at the very start and/or end of the clip.
 * Used to approximate the FADE_BLACK / CROSSFADE transition choices from the editor.
 * (True crossfade/slide/wipe transitions would need blending two overlapping clips
 * together, which this simple per-clip effect does not attempt.)
 *
 * A pure diagonal brightness scale (r,g,b all multiplied by the same factor) is safe
 * to express as a 4x4 matrix regardless of row-major/column-major convention, since a
 * diagonal matrix is its own transpose.
 */
private class FadeToBlackRgbMatrix(
    private val fadeInDurationUs: Long,
    private val fadeOutDurationUs: Long,
    private val clipDurationUs: Long
) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        var factor = 1f
        if (fadeInDurationUs > 0 && presentationTimeUs < fadeInDurationUs) {
            factor = (presentationTimeUs.toFloat() / fadeInDurationUs.toFloat()).coerceIn(0f, 1f)
        }
        if (fadeOutDurationUs > 0) {
            val fadeOutStart = clipDurationUs - fadeOutDurationUs
            if (presentationTimeUs > fadeOutStart) {
                val outFactor = ((clipDurationUs - presentationTimeUs).toFloat() / fadeOutDurationUs.toFloat())
                    .coerceIn(0f, 1f)
                factor = minOf(factor, outFactor)
            }
        }
        return floatArrayOf(
            factor, 0f, 0f, 0f,
            0f, factor, 0f, 0f,
            0f, 0f, factor, 0f,
            0f, 0f, 0f, 1f
        )
    }
}

class VideoExporter(private val context: Context) {

    private val _exportProgress = MutableStateFlow(0)
    val exportProgress: StateFlow<Int> = _exportProgress

    private val _exportState = MutableStateFlow<ExportState>(ExportState.Idle)
    val exportState: StateFlow<ExportState> = _exportState

    private var transformer: Transformer? = null
    private var progressJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    fun exportVideo(editState: VideoEditState) {
        val clips = editState.clips
        if (clips.isEmpty()) {
            _exportState.value = ExportState.Error("No video clips to export")
            return
        }

        _exportState.value = ExportState.Exporting
        _exportProgress.value = 0

        // Use cache/app-specific storage first for fast, reliable transformer output
        val outputDir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir
        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }

        val qualityTag = if (editState.exportQuality.height > 0) "${editState.exportQuality.height}p" else "HD"
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "NovaEdit_${qualityTag}_$timeStamp.mp4"
        val outputFile = File(outputDir, fileName)
        if (outputFile.exists()) {
            outputFile.delete()
        }

        startTransformerExport(editState, outputFile, fileName, allowEffects = true)
    }

    private fun startTransformerExport(
        editState: VideoEditState,
        outputFile: File,
        displayName: String,
        allowEffects: Boolean
    ) {
        val builtTransformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    progressJob?.cancel()
                    _exportProgress.value = 100

                    // Directly save to user's public device storage / Gallery
                    scope.launch(Dispatchers.IO) {
                        val galleryUri = saveVideoToGallery(context, outputFile, displayName)
                        withContext(Dispatchers.Main) {
                            _exportState.value = ExportState.Success(
                                outputPath = outputFile.absolutePath,
                                file = outputFile,
                                galleryUri = galleryUri,
                                displayName = displayName
                            )
                        }
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    transformer = null
                    progressJob?.cancel()
                    // If complex effects or secondary audio caused the failure, automatically fallback
                    if (allowEffects) {
                        scope.launch(Dispatchers.Main) {
                            // Retry clean basic export to ensure the user gets their MP4 without fail
                            startTransformerExport(editState, outputFile, displayName, allowEffects = false)
                        }
                    } else {
                        _exportState.value = ExportState.Error(
                            exportException.message ?: "Export failed. Please check video format."
                        )
                    }
                }
            })
            .build()

        transformer = builtTransformer

        val videoEffects = mutableListOf<Effect>()

        if (allowEffects) {
            // Color filters (values mirror the ones used in PhotoEditorScreen/CollageExporter
            // so the exported video tone matches what the user saw in preview)
            when (editState.filter) {
                EditorFilter.GRAYSCALE -> {
                    videoEffects.add(RgbFilter.createGrayscaleFilter())
                }
                EditorFilter.SEPIA -> {
                    // Desaturate first, then apply a warm sepia tint on top of it.
                    videoEffects.add(RgbFilter.createGrayscaleFilter())
                    videoEffects.add(
                        RgbAdjustment.Builder()
                            .setRedScale(1.35f)
                            .setGreenScale(1.05f)
                            .setBlueScale(0.70f)
                            .build()
                    )
                }
                EditorFilter.WARM -> {
                    videoEffects.add(
                        RgbAdjustment.Builder()
                            .setRedScale(1.2f)
                            .setGreenScale(1.05f)
                            .setBlueScale(0.85f)
                            .build()
                    )
                }
                EditorFilter.COOL -> {
                    videoEffects.add(
                        RgbAdjustment.Builder()
                            .setRedScale(0.85f)
                            .setGreenScale(1.0f)
                            .setBlueScale(1.25f)
                            .build()
                    )
                }
                EditorFilter.INVERT -> {
                    videoEffects.add(RgbFilter.createInvertedFilter())
                }
                EditorFilter.NONE -> {}
            }

            // Video Scale / Zoom
            if (editState.isCropped || editState.videoScale != 1.0f) {
                val scale = if (editState.isCropped && editState.videoScale == 1.0f) 1.25f else editState.videoScale
                videoEffects.add(ScaleAndRotateTransformation.Builder().setScale(scale, scale).build())
            }

            // Aspect ratio / canvas format (9:16, 1:1, 4:5, 16:9). Letterboxes/crops to fit.
            editState.aspectRatio.ratio?.let { ratio ->
                videoEffects.add(Presentation.createForAspectRatio(ratio, Presentation.LAYOUT_SCALE_TO_FIT))
            }

            // Text and Graphic overlays
            val textureOverlays = mutableListOf<TextureOverlay>()

            // 1. Custom text overlay
            if (editState.customText.isNotBlank()) {
                val spannableString = SpannableString(editState.customText)
                spannableString.setSpan(
                    ForegroundColorSpan(editState.textColor),
                    0,
                    spannableString.length,
                    0
                )
                textureOverlays.add(TextOverlay.createStaticTextOverlay(spannableString))
            }

            // 2. Graphic / Sticker overlay
            if (editState.graphicItem != null) {
                val graphic = editState.graphicItem
                val spannableGraphic = SpannableString(graphic.textOrEmoji)
                spannableGraphic.setSpan(
                    ForegroundColorSpan(Color.WHITE),
                    0,
                    spannableGraphic.length,
                    0
                )
                textureOverlays.add(TextOverlay.createStaticTextOverlay(spannableGraphic))
            }

            if (textureOverlays.isNotEmpty()) {
                videoEffects.add(OverlayEffect(textureOverlays))
            }
        }

        // Build Video Items Sequence
        val clipList = editState.clips
        val videoItems = clipList.mapIndexed { index, clip ->
            val clipBuilder = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.startMs)
            if (clip.endMs > 0) {
                clipBuilder.setEndPositionMs(clip.endMs)
            }

            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(clipBuilder.build())
                .build()

            val editedMediaItemBuilder = EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(editState.isMuted)

            // Per-clip effects = the shared filter/crop/overlay effects, plus anything
            // that only makes sense for this specific clip (its own speed, and a
            // fade-to-black approximation of its chosen transition).
            val clipVideoEffects = videoEffects.toMutableList()

            if (allowEffects && clip.speed != 1.0f) {
                clipVideoEffects.add(SpeedChangeEffect(clip.speed))
            }

            if (allowEffects && clip.transition != ClipTransition.NONE && clip.effectiveDurationMs > 0) {
                val clipDurationUs = clip.effectiveDurationMs * 1000L
                val transitionUs = (clip.transitionDurationMs * 1000L).coerceAtMost(clipDurationUs / 2)
                // Fade out at the end of every clip except the last one; fade in at the
                // start of every clip except the first one (approximates a cut-transition
                // at each junction where a transition was chosen).
                val fadeOutUs = if (index < clipList.lastIndex) transitionUs else 0L
                val fadeInUs = if (index > 0) transitionUs else 0L
                if (fadeOutUs > 0 || fadeInUs > 0) {
                    clipVideoEffects.add(FadeToBlackRgbMatrix(fadeInUs, fadeOutUs, clipDurationUs))
                }
            }

            if (clipVideoEffects.isNotEmpty()) {
                editedMediaItemBuilder.setEffects(Effects(emptyList(), clipVideoEffects))
            }
            editedMediaItemBuilder.build()
        }

        val sequences = mutableListOf<EditedMediaItemSequence>()
        sequences.add(EditedMediaItemSequence(videoItems))

        // Secondary Audio (Voiceover or Music)
        if (allowEffects) {
            val secondaryAudioUri = editState.voiceoverUri ?: editState.musicUri
            if (secondaryAudioUri != null) {
                try {
                    val audioMediaItem = MediaItem.fromUri(secondaryAudioUri)
                    val editedAudioItem = EditedMediaItem.Builder(audioMediaItem).build()
                    sequences.add(EditedMediaItemSequence(listOf(editedAudioItem)))
                } catch (_: Exception) {}
            }
        }

        val composition = Composition.Builder(sequences).build()

        transformer = builtTransformer

        try {
            builtTransformer.start(composition, outputFile.absolutePath)
        } catch (e: Exception) {
            transformer = null
            _exportState.value = ExportState.Error("Failed to initiate export: ${e.message}")
            return
        }

        // Poll progress
        progressJob = scope.launch {
            val progressHolder = ProgressHolder()
            while (isActive) {
                delay(250)
                val state = builtTransformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    _exportProgress.value = progressHolder.progress
                }
            }
        }
    }

    fun cancelExport() {
        progressJob?.cancel()
        transformer?.cancel()
        transformer = null
        _exportState.value = ExportState.Idle
        _exportProgress.value = 0
    }

    companion object {
        /**
         * Directly saves the generated MP4 file into public device storage
         * (Movies/NovaEdit or MediaStore) so it appears immediately in the user's
         * Phone Gallery, Google Photos, and File Manager without error!
         */
        fun saveVideoToGallery(context: Context, sourceFile: File, displayName: String): Uri? {
            if (!sourceFile.exists()) return null

            try {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.TITLE, displayName.substringBeforeLast("."))
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                    put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis())
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NovaEdit")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }

                val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                }

                val uri = resolver.insert(collection, values)
                if (uri != null) {
                    try {
                        resolver.openOutputStream(uri)?.use { output ->
                            sourceFile.inputStream().use { input ->
                                input.copyTo(output)
                            }
                        } ?: throw IllegalStateException("Unable to open gallery output")

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        resolver.update(uri, values, null, null)
                    }

                    // Request MediaScanner to update gallery index
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(sourceFile.absolutePath),
                        arrayOf("video/mp4"),
                        null
                    )

                        return uri
                    } catch (copyError: Exception) {
                        resolver.delete(uri, null, null)
                        throw copyError
                    }
                }
            } catch (_: Exception) {
                // Return null if permission or MediaStore fails; sourceFile is still preserved in app storage
            }
            return null
        }
    }

    sealed class ExportState {
        object Idle : ExportState()
        object Exporting : ExportState()
        data class Success(
            val outputPath: String,
            val file: File,
            val galleryUri: Uri? = null,
            val displayName: String = file.name
        ) : ExportState()
        data class Error(val message: String) : ExportState()
    }
}
