package com.example

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun testMainActivityLaunchesWithoutCrashing() {
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("NovaEdit").assertIsDisplayed()
  }

  @Test
  fun testNavigateToVideoEditor() {
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("Video Editor").performClick()
    composeTestRule.waitForIdle()
  }
}
