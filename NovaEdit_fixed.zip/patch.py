import re

with open("app/src/main/java/com/example/ui/screens/VideoEditorScreen.kt", "r") as f:
    code = f.read()

# Change videoUri to videoUris
code = code.replace(
    'var videoUri by remember { mutableStateOf<Uri?>(null) }',
    'var videoUris by remember { mutableStateOf<List<Uri>>(emptyList()) }'
)

# Replace MediaPickerLauncher
code = re.sub(
    r'val mediaPickerLauncher = rememberLauncherForActivityResult\(\s*contract = ActivityResultContracts\.GetContent\(\)\s*\) \{ uri: Uri\? ->[\s\S]*?\}',
    '''val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            videoUris = uris
            val mediaItems = uris.map { MediaItem.fromUri(it) }
            exoPlayer.setMediaItems(mediaItems)
            exoPlayer.prepare()
        }
    }''',
    code
)

# Update the 'Add Video' check
code = code.replace(
    'if (videoUri == null) {',
    'if (videoUris.isEmpty()) {'
)
code = code.replace(
    'mediaPickerLauncher.launch("video/*")',
    'mediaPickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))'
)
code = code.replace(
    'if (videoUri != null) {',
    'if (videoUris.isNotEmpty()) {'
)

# Update export button
code = code.replace(
    'if (videoUri != null) {',
    'if (videoUris.isNotEmpty()) {'
)
code = code.replace(
    'videoUri?.let { uri ->',
    'if (videoUris.isNotEmpty()) {'
)
code = code.replace(
    'videoExporter.exportVideo(uri, editState)',
    'videoExporter.exportVideo(videoUris, editState)\n}'
)

# Add Merge button to the UI
# Let's find the Tools Toolbar Row
code = code.replace(
    'EditorToolItem(',
    '''EditorToolItem(
                        icon = Icons.Default.Add, 
                        label = "Add Video", 
                        isActive = false,
                        onClick = {
                            mediaPickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                        }
                    )
                    EditorToolItem(''',
    1
)

with open("app/src/main/java/com/example/ui/screens/VideoEditorScreen.kt", "w") as f:
    f.write(code)

